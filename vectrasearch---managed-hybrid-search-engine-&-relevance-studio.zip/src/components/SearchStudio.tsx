import React, { useState, useEffect, useMemo } from 'react';
import {
  Search,
  SlidersHorizontal,
  Sparkles,
  Zap,
  Info,
  Check,
  ChevronDown,
  X,
  Layers,
  Star,
  Tag,
  Clock,
  ArrowUpDown,
} from 'lucide-react';
import { IndexSchema, SearchResultHit, SearchResponse } from '../engine/types';
import { SearchEngine } from '../engine/searchEngine';
import { AnalyticsTracker } from '../engine/analyticsStore';
import { ScoreExplainDrawer } from './ScoreExplainDrawer';

interface SearchStudioProps {
  engine: SearchEngine;
  schema: IndexSchema;
  analytics: AnalyticsTracker;
  onNavigateToRelevance?: () => void;
}

export const SearchStudio: React.FC<SearchStudioProps> = ({
  engine,
  schema,
  analytics,
  onNavigateToRelevance,
}) => {
  const [query, setQuery] = useState('');
  const [mode, setMode] = useState<'hybrid' | 'keyword_only' | 'vector_only'>(
    schema.relevance.hybridConfig.mode || 'hybrid'
  );
  const [alpha, setAlpha] = useState<number>(schema.relevance.hybridConfig.alpha ?? 0.5);
  const [selectedFilters, setSelectedFilters] = useState<Record<string, any>>({});
  const [sortBy, setSortBy] = useState<string>('');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [selectedHitForExplain, setSelectedHitForExplain] = useState<SearchResultHit | null>(null);

  // Suggested queries tailored per dataset
  const suggestedQueries = useMemo(() => {
    if (schema.id === 'ecommerce_catalog') {
      return ['iphone', 'macbook pro', 'noise cancelling', 'fujifilm', '4k oled', 'ergonomic'];
    }
    if (schema.id === 'developer_docs') {
      return ['quickstart', 'vector', 'auth token', 'typo tolerance', 'analytics ctr', 'facets'];
    }
    if (schema.id === 'media_entertainment') {
      return ['space exploration', 'christopher nolan', 'sci-fi', 'heist dream', 'detective noir'];
    }
    return ['search', 'data', 'hybrid'];
  }, [schema.id]);

  // Execute Search
  const searchResponse: SearchResponse = useMemo(() => {
    const res = engine.search({
      query,
      mode,
      alpha,
      filters: selectedFilters,
      sortBy: sortBy || undefined,
      sortOrder,
      page: 1,
      perPage: 20,
    });

    // Record telemetry query
    analytics.recordQuery({
      query,
      latencyMs: res.processingTimeMs,
      hitsCount: res.totalHits,
      filtersUsed: Object.keys(selectedFilters),
      mode,
    });

    return res;
  }, [engine, query, mode, alpha, selectedFilters, sortBy, sortOrder, schema]);

  // Handle clicking a hit (records click in analytics)
  const handleHitClick = (hit: SearchResultHit) => {
    analytics.recordClick('latest', hit.id);
  };

  const handleFilterToggle = (field: string, value: string) => {
    setSelectedFilters((prev) => {
      const next = { ...prev };
      if (next[field] === value) {
        delete next[field];
      } else {
        next[field] = value;
      }
      return next;
    });
  };

  const handleClearFilters = () => {
    setSelectedFilters({});
    setSortBy('');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Top Search Controls Bar */}
      <div className="bg-neutral-900/90 border border-neutral-800 rounded-xl p-4 sm:p-5 shadow-sm space-y-4">
        {/* Search Input Field */}
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-neutral-400">
            <Search className="w-5 h-5 text-neutral-400" />
          </div>
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={`Search across ${schema.name}... (e.g. try typing with typos or conceptual queries)`}
            className="w-full bg-neutral-950 border border-neutral-700/80 rounded-lg pl-11 pr-24 py-3 text-sm text-neutral-100 placeholder-neutral-500 focus:outline-none focus:ring-1 focus:ring-cyan-500/50 focus:border-cyan-500 transition-all font-medium"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="absolute inset-y-0 right-14 pr-2 flex items-center text-neutral-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <div className="absolute inset-y-0 right-0 pr-3.5 flex items-center pointer-events-none">
            <span className="text-[11px] font-mono text-neutral-500 border border-neutral-800 rounded px-1.5 py-0.5">
              Live
            </span>
          </div>
        </div>

        {/* Query Suggestions Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
          <span className="text-neutral-500 shrink-0 flex items-center gap-1 font-mono text-[11px]">
            <Sparkles className="w-3 h-3 text-cyan-400" /> Quick queries:
          </span>
          {suggestedQueries.map((suggested) => (
            <button
              key={suggested}
              onClick={() => setQuery(suggested)}
              className={`px-2.5 py-1 rounded text-xs transition-colors whitespace-nowrap border ${
                query === suggested
                  ? 'bg-cyan-500/10 border-cyan-500/40 text-cyan-300 font-medium'
                  : 'bg-neutral-950/60 border-neutral-800 text-neutral-400 hover:text-neutral-200 hover:border-neutral-700'
              }`}
            >
              {suggested}
            </button>
          ))}
        </div>

        {/* Engine Mode & Alpha Hybrid Tuning Bar */}
        <div className="pt-3 border-t border-neutral-800/80 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 text-xs">
          {/* Search Mode Segmented Control */}
          <div className="flex items-center gap-2">
            <span className="text-neutral-400 font-mono text-[11px]">Retrieval Mode:</span>
            <div className="flex items-center p-0.5 bg-neutral-950 border border-neutral-800 rounded-lg">
              <button
                onClick={() => setMode('hybrid')}
                className={`px-3 py-1.5 rounded-md font-medium transition-all ${
                  mode === 'hybrid'
                    ? 'bg-neutral-800 text-cyan-300 shadow-sm'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                Hybrid (BM25 + Vector)
              </button>
              <button
                onClick={() => setMode('keyword_only')}
                className={`px-3 py-1.5 rounded-md font-medium transition-all ${
                  mode === 'keyword_only'
                    ? 'bg-neutral-800 text-cyan-300 shadow-sm'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                BM25 Keyword Only
              </button>
              <button
                onClick={() => setMode('vector_only')}
                className={`px-3 py-1.5 rounded-md font-medium transition-all ${
                  mode === 'vector_only'
                    ? 'bg-neutral-800 text-cyan-300 shadow-sm'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                Vector Only (Cosine)
              </button>
            </div>
          </div>

          {/* Alpha Weight Slider (Visible when mode is Hybrid) */}
          {mode === 'hybrid' && (
            <div className="flex items-center gap-3 w-full md:w-auto bg-neutral-950/80 border border-neutral-800 px-3 py-1.5 rounded-lg">
              <span className="text-neutral-400 font-mono text-[11px] whitespace-nowrap">
                Alpha Weight (&alpha;):
              </span>
              <div className="flex items-center gap-2 flex-1 md:w-48">
                <span className="text-[10px] font-mono text-neutral-500">BM25</span>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={alpha}
                  onChange={(e) => setAlpha(parseFloat(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer h-1.5 bg-neutral-800 rounded-lg"
                />
                <span className="text-[10px] font-mono text-neutral-500">Vector</span>
              </div>
              <span className="font-mono text-cyan-300 text-xs font-semibold tabular-nums min-w-[32px]">
                {alpha.toFixed(2)}
              </span>
            </div>
          )}

          {/* Sort Selector */}
          <div className="flex items-center gap-2">
            <span className="text-neutral-400 font-mono text-[11px]">Sort By:</span>
            <select
              value={sortBy}
              onChange={(e) => {
                const val = e.target.value;
                setSortBy(val);
                if (val === 'price') setSortOrder('asc');
                else setSortOrder('desc');
              }}
              className="bg-neutral-950 border border-neutral-800 rounded-md px-2.5 py-1.5 text-xs text-neutral-200 focus:outline-none cursor-pointer"
            >
              <option value="">Relevance Score</option>
              {schema.id === 'ecommerce_catalog' && (
                <>
                  <option value="price">Price (Low to High)</option>
                  <option value="rating">Rating (Highest)</option>
                  <option value="sales_count">Best Sellers</option>
                </>
              )}
              {schema.id === 'developer_docs' && (
                <option value="views">Most Viewed</option>
              )}
              {schema.id === 'media_entertainment' && (
                <>
                  <option value="rating">IMDb Rating</option>
                  <option value="year">Release Year</option>
                  <option value="votes">Total Votes</option>
                </>
              )}
            </select>
          </div>
        </div>
      </div>

      {/* Merchandising Rule Banner (if triggered) */}
      {searchResponse.activeRuleApplied && (
        <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg px-4 py-2.5 flex items-center justify-between text-xs text-amber-300">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-amber-400" />
            <span>
              <strong>Merchandising Rule Applied:</strong> {searchResponse.activeRuleApplied}
            </span>
          </div>
          {onNavigateToRelevance && (
            <button
              onClick={onNavigateToRelevance}
              className="underline text-amber-200 hover:text-white"
            >
              View in Rules &rarr;
            </button>
          )}
        </div>
      )}

      {/* Main Studio Split Layout: Facet Filters (Left) + Search Hits (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
        {/* Left Column: Facet Filters */}
        <aside className="lg:col-span-1 bg-neutral-900/60 border border-neutral-800 rounded-xl p-4 space-y-5 text-xs">
          <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
            <h3 className="font-semibold text-neutral-200 flex items-center gap-1.5 uppercase font-mono tracking-wider text-[11px]">
              <SlidersHorizontal className="w-3.5 h-3.5 text-cyan-400" />
              Faceted Filters
            </h3>
            {Object.keys(selectedFilters).length > 0 && (
              <button
                onClick={handleClearFilters}
                className="text-[11px] text-cyan-400 hover:text-cyan-300 underline"
              >
                Clear all
              </button>
            )}
          </div>

          {/* Dynamic Facet Groups */}
          {Object.entries(searchResponse.facets).map(([facetField, facetList]) => {
            if (facetList.length === 0) return null;
            return (
              <div key={facetField} className="space-y-2">
                <div className="font-medium text-neutral-300 capitalize font-mono text-[11px] flex items-center justify-between">
                  <span>{facetField.replace('_', ' ')}</span>
                  <span className="text-[10px] text-neutral-500">
                    {selectedFilters[facetField] ? 'Active' : ''}
                  </span>
                </div>
                <div className="space-y-1 max-h-40 overflow-y-auto pr-1">
                  {facetList.map((item) => {
                    const isSelected = selectedFilters[facetField] === item.value;
                    return (
                      <button
                        key={item.value}
                        onClick={() => handleFilterToggle(facetField, item.value)}
                        className={`w-full flex items-center justify-between px-2 py-1.5 rounded transition-colors text-left ${
                          isSelected
                            ? 'bg-cyan-500/15 text-cyan-300 font-medium'
                            : 'text-neutral-400 hover:bg-neutral-800 hover:text-neutral-200'
                        }`}
                      >
                        <span className="truncate pr-2">{item.value}</span>
                        <span className="font-mono text-[10px] text-neutral-500 tabular-nums">
                          {item.count}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })}

          {/* Quick Boolean Filters */}
          {schema.id === 'ecommerce_catalog' && (
            <div className="pt-3 border-t border-neutral-800 space-y-2">
              <div className="font-mono text-[11px] text-neutral-300">Availability</div>
              <label className="flex items-center gap-2 text-neutral-400 cursor-pointer">
                <input
                  type="checkbox"
                  checked={Boolean(selectedFilters.inStockOnly)}
                  onChange={(e) =>
                    setSelectedFilters((prev) => ({
                      ...prev,
                      inStockOnly: e.target.checked || undefined,
                    }))
                  }
                  className="rounded border-neutral-700 bg-neutral-950 text-cyan-500 focus:ring-0"
                />
                <span>In Stock items only</span>
              </label>
            </div>
          )}

          {/* Index Information Widget */}
          <div className="pt-3 border-t border-neutral-800 text-[11px] text-neutral-500 space-y-1 font-mono">
            <div>Vector Dim: {schema.vectorDimension}D ({schema.distanceMetric})</div>
            <div>Typo Tolerance: {schema.relevance.typoTolerance.enabled ? 'Active (Levenshtein)' : 'Disabled'}</div>
            <div>Synonyms: {schema.relevance.synonyms.length} rules loaded</div>
          </div>
        </aside>

        {/* Right Column: Search Results Stream */}
        <main className="lg:col-span-3 space-y-4">
          {/* Results Summary Bar */}
          <div className="flex items-center justify-between text-xs text-neutral-400 px-1">
            <div className="flex items-center gap-2">
              <span className="font-medium text-neutral-200 tabular-nums">
                {searchResponse.totalHits} {searchResponse.totalHits === 1 ? 'result' : 'results'}
              </span>
              <span>·</span>
              <span className="font-mono text-cyan-400 tabular-nums">
                {searchResponse.processingTimeMs} ms
              </span>
              <span>·</span>
              <span className="text-neutral-500">
                Mode: {mode.replace('_', ' ')}
              </span>
            </div>

            {searchResponse.hits.length > 0 && (
              <span className="text-[11px] text-neutral-500 hidden sm:inline">
                Click &quot;Inspect Score&quot; to see BM25 &amp; Vector equation
              </span>
            )}
          </div>

          {/* Empty State */}
          {searchResponse.hits.length === 0 && (
            <div className="bg-neutral-900/40 border border-dashed border-neutral-800 rounded-xl p-12 text-center space-y-3">
              <div className="w-10 h-10 rounded-full bg-neutral-800/80 flex items-center justify-center mx-auto text-neutral-400">
                <Search className="w-5 h-5" />
              </div>
              <h4 className="text-sm font-semibold text-neutral-200">No results found</h4>
              <p className="text-xs text-neutral-400 max-w-sm mx-auto">
                No documents matched &quot;{query}&quot; with current filters. Try relaxing filters or test adding a synonym in Relevance Tuning!
              </p>
              <div className="pt-2">
                <button
                  onClick={() => {
                    setQuery('');
                    setSelectedFilters({});
                  }}
                  className="px-3.5 py-1.5 text-xs bg-neutral-800 text-neutral-200 hover:text-white rounded-md transition-colors"
                >
                  Reset Search
                </button>
              </div>
            </div>
          )}

          {/* Hit Cards Stream */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {searchResponse.hits.map((hit, idx) => {
              const doc = hit.document;
              return (
                <div
                  key={hit.id}
                  onClick={() => handleHitClick(hit)}
                  className={`bg-neutral-900/70 hover:bg-neutral-900 border transition-all rounded-xl p-4 flex flex-col justify-between group ${
                    hit.breakdown.isPinned
                      ? 'border-amber-500/50 bg-amber-950/10'
                      : 'border-neutral-800 hover:border-neutral-700'
                  }`}
                >
                  {/* Card Header: Category & Score */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs text-neutral-400">
                      <div className="flex items-center gap-1.5 truncate max-w-[200px]">
                        {hit.breakdown.isPinned && (
                          <span className="text-amber-400 flex items-center gap-1 font-mono text-[10px]">
                            <Zap className="w-3 h-3 fill-amber-400" /> Pinned
                          </span>
                        )}
                        <span className="text-neutral-400 truncate">
                          {doc.brand || doc.section || doc.director || 'Document'}
                        </span>
                        {doc.category && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="text-neutral-500 truncate">{doc.category}</span>
                          </>
                        )}
                      </div>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedHitForExplain(hit);
                        }}
                        className="font-mono text-[11px] text-cyan-400 hover:text-cyan-300 bg-cyan-950/40 border border-cyan-800/40 rounded px-1.5 py-0.5 tabular-nums flex items-center gap-1 transition-colors"
                        title="Click to view full relevance score calculation"
                      >
                        Score: {hit.score.toFixed(2)}
                        <Info className="w-2.5 h-2.5" />
                      </button>
                    </div>

                    {/* Title with Highlight */}
                    <h4
                      className="text-sm font-semibold text-neutral-100 group-hover:text-cyan-200 transition-colors leading-snug"
                      dangerouslySetInnerHTML={{
                        __html: hit.highlights.title || doc.title || doc.name || doc.id,
                      }}
                    />

                    {/* Description or Summary */}
                    {(doc.description || doc.summary || doc.synopsis) && (
                      <p
                        className="text-xs text-neutral-400 line-clamp-2 leading-relaxed"
                        dangerouslySetInnerHTML={{
                          __html:
                            hit.highlights.description ||
                            hit.highlights.summary ||
                            hit.highlights.synopsis ||
                            doc.description ||
                            doc.summary ||
                            doc.synopsis ||
                            '',
                        }}
                      />
                    )}

                    {/* Endpoint / Code Snippet (for developer docs) */}
                    {doc.endpoint && (
                      <div className="bg-neutral-950 border border-neutral-800 rounded px-2 py-1 font-mono text-[11px] text-neutral-300 truncate">
                        {doc.endpoint}
                      </div>
                    )}
                  </div>

                  {/* Card Footer: Metadata and Action */}
                  <div className="pt-3 mt-3 border-t border-neutral-800/80 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-3 text-neutral-400">
                      {doc.price !== undefined && (
                        <span className="font-mono font-bold text-neutral-100 tabular-nums">
                          ${doc.price}
                        </span>
                      )}
                      {doc.rating !== undefined && (
                        <span className="flex items-center gap-1 text-amber-400 font-mono tabular-nums text-[11px]">
                          <Star className="w-3 h-3 fill-amber-400" />
                          {doc.rating}
                        </span>
                      )}
                      {doc.year !== undefined && (
                        <span className="font-mono text-neutral-500 tabular-nums">
                          {doc.year}
                        </span>
                      )}
                      {doc.stock !== undefined && (
                        <span className="text-[11px] text-neutral-500">
                          {doc.stock > 0 ? `${doc.stock} in stock` : 'Out of stock'}
                        </span>
                      )}
                    </div>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedHitForExplain(hit);
                      }}
                      className="text-[11px] text-neutral-400 hover:text-cyan-300 underline transition-colors"
                    >
                      Explain score &rarr;
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </main>
      </div>

      {/* Score Explain Drawer */}
      <ScoreExplainDrawer
        hit={selectedHitForExplain}
        onClose={() => setSelectedHitForExplain(null)}
        query={query}
      />
    </div>
  );
};
