import React, { useState } from 'react';
import {
  Sliders,
  Plus,
  Trash2,
  ArrowUp,
  ArrowDown,
  Zap,
  Tag,
  Sparkles,
  Check,
  RotateCcw,
  Pin,
  Compass,
  FileText,
} from 'lucide-react';
import {
  IndexSchema,
  SearchableAttributeWeight,
  CustomRankingRule,
  SynonymRule,
  MerchandisingRule,
} from '../engine/types';

interface RelevanceTuningProps {
  schema: IndexSchema;
  onUpdateSchema: (updated: IndexSchema) => void;
  documentList: Array<{ id: string; title?: string; name?: string }>;
}

export const RelevanceTuning: React.FC<RelevanceTuningProps> = ({
  schema,
  onUpdateSchema,
  documentList,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<
    'searchable' | 'ranking' | 'typos' | 'synonyms' | 'rules' | 'vector'
  >('searchable');

  const [savedSuccess, setSavedSuccess] = useState(false);

  // Synonym Test input
  const [synonymTestWord, setSynonymTestWord] = useState('phone');

  // New synonym draft state
  const [newSynonymType, setNewSynonymType] = useState<'two-way' | 'one-way'>('two-way');
  const [newSynonymTerms, setNewSynonymTerms] = useState('');
  const [newSynonymRoot, setNewSynonymRoot] = useState('');

  // New Rule draft state
  const [newRuleName, setNewRuleName] = useState('');
  const [newRuleQuery, setNewRuleQuery] = useState('');
  const [newRulePinDocId, setNewRulePinDocId] = useState(documentList[0]?.id || '');

  const triggerSaveNotification = () => {
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2000);
  };

  // 1. Searchable Attributes handlers
  const handleWeightChange = (index: number, newWeight: number) => {
    const updatedAttrs = [...schema.relevance.searchableAttributes];
    updatedAttrs[index].weight = newWeight;
    onUpdateSchema({
      ...schema,
      relevance: { ...schema.relevance, searchableAttributes: updatedAttrs },
    });
    triggerSaveNotification();
  };

  const handleMoveAttr = (index: number, direction: 'up' | 'down') => {
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= schema.relevance.searchableAttributes.length) return;

    const list = [...schema.relevance.searchableAttributes];
    const [moved] = list.splice(index, 1);
    list.splice(targetIndex, 0, moved);

    onUpdateSchema({
      ...schema,
      relevance: { ...schema.relevance, searchableAttributes: list },
    });
    triggerSaveNotification();
  };

  const handleAddSearchableAttr = (fieldName: string) => {
    if (!fieldName) return;
    if (schema.relevance.searchableAttributes.some((a) => a.field === fieldName)) return;

    const updated = [
      ...schema.relevance.searchableAttributes,
      { field: fieldName, weight: 5 },
    ];
    onUpdateSchema({
      ...schema,
      relevance: { ...schema.relevance, searchableAttributes: updated },
    });
    triggerSaveNotification();
  };

  const handleRemoveSearchableAttr = (fieldName: string) => {
    const updated = schema.relevance.searchableAttributes.filter((a) => a.field !== fieldName);
    onUpdateSchema({
      ...schema,
      relevance: { ...schema.relevance, searchableAttributes: updated },
    });
    triggerSaveNotification();
  };

  // 2. Custom Ranking handlers
  const handleAddCustomRanking = (fieldName: string) => {
    if (!fieldName) return;
    if (schema.relevance.customRanking.some((r) => r.field === fieldName)) return;

    const updated = [...schema.relevance.customRanking, { field: fieldName, order: 'desc' as const }];
    onUpdateSchema({
      ...schema,
      relevance: { ...schema.relevance, customRanking: updated },
    });
    triggerSaveNotification();
  };

  const handleToggleRankOrder = (index: number) => {
    const updated = [...schema.relevance.customRanking];
    updated[index].order = updated[index].order === 'asc' ? 'desc' : 'asc';
    onUpdateSchema({
      ...schema,
      relevance: { ...schema.relevance, customRanking: updated },
    });
    triggerSaveNotification();
  };

  const handleRemoveCustomRanking = (index: number) => {
    const updated = schema.relevance.customRanking.filter((_, i) => i !== index);
    onUpdateSchema({
      ...schema,
      relevance: { ...schema.relevance, customRanking: updated },
    });
    triggerSaveNotification();
  };

  // 3. Typo Tolerance handlers
  const handleTypoToggle = (enabled: boolean) => {
    onUpdateSchema({
      ...schema,
      relevance: {
        ...schema.relevance,
        typoTolerance: { ...schema.relevance.typoTolerance, enabled },
      },
    });
    triggerSaveNotification();
  };

  const handleTypoMinChange = (key: 'minWordSizeForOneTypo' | 'minWordSizeForTwoTypos', val: number) => {
    onUpdateSchema({
      ...schema,
      relevance: {
        ...schema.relevance,
        typoTolerance: { ...schema.relevance.typoTolerance, [key]: val },
      },
    });
    triggerSaveNotification();
  };

  // 4. Synonym Handlers
  const handleAddSynonym = (e: React.FormEvent) => {
    e.preventDefault();
    const terms = newSynonymTerms
      .split(',')
      .map((t) => t.trim())
      .filter(Boolean);

    if (terms.length === 0) return;

    const newSyn: SynonymRule = {
      id: 'syn_' + Math.random().toString(36).substring(2, 7),
      type: newSynonymType,
      terms,
      rootTerm: newSynonymType === 'one-way' ? newSynonymRoot.trim() : undefined,
    };

    onUpdateSchema({
      ...schema,
      relevance: {
        ...schema.relevance,
        synonyms: [...schema.relevance.synonyms, newSyn],
      },
    });

    setNewSynonymTerms('');
    setNewSynonymRoot('');
    triggerSaveNotification();
  };

  const handleRemoveSynonym = (id: string) => {
    onUpdateSchema({
      ...schema,
      relevance: {
        ...schema.relevance,
        synonyms: schema.relevance.synonyms.filter((s) => s.id !== id),
      },
    });
    triggerSaveNotification();
  };

  // Live synonym expansion preview
  const expandedSynonymList = React.useMemo(() => {
    const target = synonymTestWord.toLowerCase().trim();
    if (!target) return [];
    const results = new Set<string>();

    for (const syn of schema.relevance.synonyms) {
      if (syn.type === 'two-way') {
        if (syn.terms.map((t) => t.toLowerCase()).includes(target)) {
          syn.terms.forEach((t) => results.add(t));
        }
      } else if (syn.type === 'one-way') {
        if (syn.rootTerm && syn.rootTerm.toLowerCase() === target) {
          syn.terms.forEach((t) => results.add(t));
        }
      }
    }
    return Array.from(results);
  }, [synonymTestWord, schema.relevance.synonyms]);

  // 5. Merchandising Rules handlers
  const handleToggleRule = (ruleId: string) => {
    const updated = schema.relevance.rules.map((r) =>
      r.id === ruleId ? { ...r, enabled: !r.enabled } : r
    );
    onUpdateSchema({
      ...schema,
      relevance: { ...schema.relevance, rules: updated },
    });
    triggerSaveNotification();
  };

  const handleAddRule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRuleName.trim() || !newRuleQuery.trim()) return;

    const newRule: MerchandisingRule = {
      id: 'rule_' + Math.random().toString(36).substring(2, 7),
      name: newRuleName.trim(),
      enabled: true,
      condition: {
        type: 'query_exact',
        value: newRuleQuery.trim().toLowerCase(),
      },
      action: {
        pinDocId: newRulePinDocId,
        pinPosition: 1,
      },
    };

    onUpdateSchema({
      ...schema,
      relevance: {
        ...schema.relevance,
        rules: [...schema.relevance.rules, newRule],
      },
    });

    setNewRuleName('');
    setNewRuleQuery('');
    triggerSaveNotification();
  };

  const handleRemoveRule = (ruleId: string) => {
    onUpdateSchema({
      ...schema,
      relevance: {
        ...schema.relevance,
        rules: schema.relevance.rules.filter((r) => r.id !== ruleId),
      },
    });
    triggerSaveNotification();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-neutral-800">
        <div>
          <h2 className="text-lg font-bold text-neutral-100 flex items-center gap-2">
            <Sliders className="w-5 h-5 text-cyan-400" />
            Relevance & Ranking Engine
          </h2>
          <p className="text-xs text-neutral-400 mt-0.5">
            Configure attribute weights, tie-breaking formulas, typo tolerance thresholds, synonym dictionaries, and merchandising rules.
          </p>
        </div>

        {savedSuccess && (
          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/30 rounded-md text-emerald-300 text-xs font-medium">
            <Check className="w-4 h-4 text-emerald-400" />
            Changes saved to index
          </div>
        )}
      </div>

      {/* Sub-Navigation Tabs */}
      <div className="flex items-center gap-1 overflow-x-auto pb-1 border-b border-neutral-800 text-xs">
        <button
          onClick={() => setActiveSubTab('searchable')}
          className={`px-3.5 py-2 font-medium border-b-2 transition-all whitespace-nowrap ${
            activeSubTab === 'searchable'
              ? 'border-cyan-400 text-cyan-300'
              : 'border-transparent text-neutral-400 hover:text-neutral-200'
          }`}
        >
          1. Searchable Attributes
        </button>

        <button
          onClick={() => setActiveSubTab('ranking')}
          className={`px-3.5 py-2 font-medium border-b-2 transition-all whitespace-nowrap ${
            activeSubTab === 'ranking'
              ? 'border-cyan-400 text-cyan-300'
              : 'border-transparent text-neutral-400 hover:text-neutral-200'
          }`}
        >
          2. Custom Ranking Criteria
        </button>

        <button
          onClick={() => setActiveSubTab('typos')}
          className={`px-3.5 py-2 font-medium border-b-2 transition-all whitespace-nowrap ${
            activeSubTab === 'typos'
              ? 'border-cyan-400 text-cyan-300'
              : 'border-transparent text-neutral-400 hover:text-neutral-200'
          }`}
        >
          3. Typo Tolerance
        </button>

        <button
          onClick={() => setActiveSubTab('synonyms')}
          className={`px-3.5 py-2 font-medium border-b-2 transition-all whitespace-nowrap ${
            activeSubTab === 'synonyms'
              ? 'border-cyan-400 text-cyan-300'
              : 'border-transparent text-neutral-400 hover:text-neutral-200'
          }`}
        >
          4. Synonyms & Aliases
        </button>

        <button
          onClick={() => setActiveSubTab('rules')}
          className={`px-3.5 py-2 font-medium border-b-2 transition-all whitespace-nowrap ${
            activeSubTab === 'rules'
              ? 'border-cyan-400 text-cyan-300'
              : 'border-transparent text-neutral-400 hover:text-neutral-200'
          }`}
        >
          5. Merchandising Rules
        </button>

        <button
          onClick={() => setActiveSubTab('vector')}
          className={`px-3.5 py-2 font-medium border-b-2 transition-all whitespace-nowrap ${
            activeSubTab === 'vector'
              ? 'border-cyan-400 text-cyan-300'
              : 'border-transparent text-neutral-400 hover:text-neutral-200'
          }`}
        >
          6. Vector & HNSW Config
        </button>
      </div>

      {/* Tab 1: Searchable Attributes */}
      {activeSubTab === 'searchable' && (
        <div className="space-y-4">
          <div className="bg-neutral-900/60 border border-neutral-800 rounded-xl p-5 space-y-4">
            <div>
              <h3 className="text-sm font-semibold text-neutral-200">
                Searchable Fields &amp; Priority Boosts
              </h3>
              <p className="text-xs text-neutral-400 mt-1">
                Matches in higher-priority attributes score significantly higher than matches in lower ones. Reorder or modify relative field weights below.
              </p>
            </div>

            {/* Attributes List */}
            <div className="space-y-2.5">
              {schema.relevance.searchableAttributes.map((attr, index) => (
                <div
                  key={attr.field}
                  className="bg-neutral-950 border border-neutral-800/90 rounded-lg p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                >
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-neutral-500 tabular-nums w-5 text-[11px]">
                      #{index + 1}
                    </span>
                    <span className="font-mono font-semibold text-neutral-200">
                      {attr.field}
                    </span>
                    <span className="text-[11px] text-neutral-500 font-mono">
                      (Type: {schema.fields.find((f) => f.name === attr.field)?.type || 'string'})
                    </span>
                  </div>

                  <div className="flex items-center gap-4">
                    {/* Weight Slider */}
                    <div className="flex items-center gap-2">
                      <span className="text-neutral-400 font-mono text-[11px]">Weight:</span>
                      <input
                        type="range"
                        min="1"
                        max="20"
                        value={attr.weight}
                        onChange={(e) => handleWeightChange(index, parseInt(e.target.value))}
                        className="w-24 accent-cyan-400 h-1 bg-neutral-800 cursor-pointer"
                      />
                      <span className="font-mono text-cyan-300 font-semibold tabular-nums w-7 text-right">
                        {attr.weight}&times;
                      </span>
                    </div>

                    {/* Up / Down Reorder */}
                    <div className="flex items-center border border-neutral-800 rounded">
                      <button
                        onClick={() => handleMoveAttr(index, 'up')}
                        disabled={index === 0}
                        className="p-1 text-neutral-400 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed"
                      >
                        <ArrowUp className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleMoveAttr(index, 'down')}
                        disabled={index === schema.relevance.searchableAttributes.length - 1}
                        className="p-1 text-neutral-400 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed border-l border-neutral-800"
                      >
                        <ArrowDown className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {/* Remove */}
                    <button
                      onClick={() => handleRemoveSearchableAttr(attr.field)}
                      className="p-1 text-neutral-500 hover:text-rose-400 transition-colors"
                      title="Remove from searchable attributes"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Add Attribute Dropdown */}
            <div className="pt-2 flex items-center gap-2">
              <span className="text-xs text-neutral-400 font-mono text-[11px]">
                Add field to searchable index:
              </span>
              <select
                onChange={(e) => {
                  if (e.target.value) {
                    handleAddSearchableAttr(e.target.value);
                    e.target.value = '';
                  }
                }}
                className="bg-neutral-950 border border-neutral-800 rounded px-2.5 py-1 text-xs text-neutral-200 focus:outline-none"
              >
                <option value="">Select unindexed schema field...</option>
                {schema.fields
                  .filter(
                    (f) =>
                      f.type !== 'vector' &&
                      !schema.relevance.searchableAttributes.some((a) => a.field === f.name)
                  )
                  .map((f) => (
                    <option key={f.name} value={f.name}>
                      {f.name} ({f.type})
                    </option>
                  ))}
              </select>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Custom Ranking Criteria */}
      {activeSubTab === 'ranking' && (
        <div className="bg-neutral-900/60 border border-neutral-800 rounded-xl p-5 space-y-4">
          <div>
            <h3 className="text-sm font-semibold text-neutral-200">
              Custom Business Ranking Rules (Tie-Breaking)
            </h3>
            <p className="text-xs text-neutral-400 mt-1">
              When two or more documents have identical textual or semantic relevance, VectraSearch applies these business criteria in sequential order.
            </p>
          </div>

          <div className="space-y-2.5">
            {schema.relevance.customRanking.map((rule, idx) => (
              <div
                key={rule.field}
                className="bg-neutral-950 border border-neutral-800 rounded-lg p-3 flex items-center justify-between text-xs"
              >
                <div className="flex items-center gap-3">
                  <span className="font-mono text-neutral-500 tabular-nums w-5 text-[11px]">
                    #{idx + 1}
                  </span>
                  <span className="font-mono font-semibold text-neutral-200">{rule.field}</span>
                </div>

                <div className="flex items-center gap-3">
                  <button
                    onClick={() => handleToggleRankOrder(idx)}
                    className="font-mono px-2.5 py-1 bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 rounded text-cyan-300 transition-colors"
                  >
                    {rule.order === 'desc' ? 'Descending (High -> Low)' : 'Ascending (Low -> High)'}
                  </button>

                  <button
                    onClick={() => handleRemoveCustomRanking(idx)}
                    className="p-1 text-neutral-500 hover:text-rose-400 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Add Ranking Rule */}
          <div className="pt-2 flex items-center gap-2">
            <span className="text-xs text-neutral-400 font-mono text-[11px]">Add tie-breaker:</span>
            <select
              onChange={(e) => {
                if (e.target.value) {
                  handleAddCustomRanking(e.target.value);
                  e.target.value = '';
                }
              }}
              className="bg-neutral-950 border border-neutral-800 rounded px-2.5 py-1 text-xs text-neutral-200 focus:outline-none"
            >
              <option value="">Select numeric or date attribute...</option>
              {schema.fields
                .filter(
                  (f) =>
                    f.sortable &&
                    !schema.relevance.customRanking.some((r) => r.field === f.name)
                )
                .map((f) => (
                  <option key={f.name} value={f.name}>
                    {f.name} ({f.type})
                  </option>
                ))}
            </select>
          </div>
        </div>
      )}

      {/* Tab 3: Typo Tolerance */}
      {activeSubTab === 'typos' && (
        <div className="bg-neutral-900/60 border border-neutral-800 rounded-xl p-5 space-y-5 text-xs">
          <div>
            <h3 className="text-sm font-semibold text-neutral-200">
              Fuzzy Typo Tolerance (Damerau-Levenshtein)
            </h3>
            <p className="text-neutral-400 mt-1">
              Automatically matches customer misspellings and transpositions with smooth score penalties.
            </p>
          </div>

          {/* Master Toggle */}
          <div className="flex items-center justify-between p-3.5 bg-neutral-950 border border-neutral-800 rounded-lg">
            <div>
              <span className="font-semibold text-neutral-200">Enable Typo Tolerance</span>
              <p className="text-neutral-400 text-[11px]">
                When active, queries with 1 or 2 character edits will match relevant catalog items.
              </p>
            </div>
            <input
              type="checkbox"
              checked={schema.relevance.typoTolerance.enabled}
              onChange={(e) => handleTypoToggle(e.target.checked)}
              className="w-4 h-4 accent-cyan-400 cursor-pointer"
            />
          </div>

          {/* Min Word Sizes */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-3.5 bg-neutral-950 border border-neutral-800 rounded-lg space-y-2">
              <span className="font-medium text-neutral-200 font-mono text-[11px]">
                Min word length for 1 typo
              </span>
              <p className="text-[11px] text-neutral-400">
                Words shorter than this threshold require exact spelling. (Default: 4 chars)
              </p>
              <input
                type="number"
                min="2"
                max="8"
                value={schema.relevance.typoTolerance.minWordSizeForOneTypo}
                onChange={(e) =>
                  handleTypoMinChange('minWordSizeForOneTypo', parseInt(e.target.value) || 4)
                }
                className="w-full bg-neutral-900 border border-neutral-800 rounded px-2.5 py-1.5 text-neutral-200 font-mono"
              />
            </div>

            <div className="p-3.5 bg-neutral-950 border border-neutral-800 rounded-lg space-y-2">
              <span className="font-medium text-neutral-200 font-mono text-[11px]">
                Min word length for 2 typos
              </span>
              <p className="text-[11px] text-neutral-400">
                Longer query words that allow up to 2 edits or letter transpositions. (Default: 8 chars)
              </p>
              <input
                type="number"
                min="6"
                max="14"
                value={schema.relevance.typoTolerance.minWordSizeForTwoTypos}
                onChange={(e) =>
                  handleTypoMinChange('minWordSizeForTwoTypos', parseInt(e.target.value) || 8)
                }
                className="w-full bg-neutral-900 border border-neutral-800 rounded px-2.5 py-1.5 text-neutral-200 font-mono"
              />
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: Synonyms */}
      {activeSubTab === 'synonyms' && (
        <div className="space-y-5 text-xs">
          {/* Add Synonym Rule Card */}
          <div className="bg-neutral-900/60 border border-neutral-800 rounded-xl p-5 space-y-4">
            <h3 className="text-sm font-semibold text-neutral-200 flex items-center gap-1.5">
              <Tag className="w-4 h-4 text-cyan-400" />
              Add Synonym Dictionary Rule
            </h3>

            <form onSubmit={handleAddSynonym} className="grid grid-cols-1 md:grid-cols-4 gap-3">
              <div>
                <label className="text-neutral-400 font-mono text-[11px] block mb-1">
                  Type:
                </label>
                <select
                  value={newSynonymType}
                  onChange={(e) => setNewSynonymType(e.target.value as any)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded px-2.5 py-1.5 text-neutral-200"
                >
                  <option value="two-way">Two-Way (Bidirectional)</option>
                  <option value="one-way">One-Way (Root Expansion)</option>
                </select>
              </div>

              {newSynonymType === 'one-way' && (
                <div>
                  <label className="text-neutral-400 font-mono text-[11px] block mb-1">
                    Root Term:
                  </label>
                  <input
                    type="text"
                    value={newSynonymRoot}
                    onChange={(e) => setNewSynonymRoot(e.target.value)}
                    placeholder="e.g. tablet"
                    className="w-full bg-neutral-950 border border-neutral-800 rounded px-2.5 py-1.5 text-neutral-200"
                  />
                </div>
              )}

              <div className={newSynonymType === 'one-way' ? 'md:col-span-2' : 'md:col-span-2'}>
                <label className="text-neutral-400 font-mono text-[11px] block mb-1">
                  Synonym Terms (comma-separated):
                </label>
                <input
                  type="text"
                  value={newSynonymTerms}
                  onChange={(e) => setNewSynonymTerms(e.target.value)}
                  placeholder="e.g. ipad, slate, android tablet"
                  className="w-full bg-neutral-950 border border-neutral-800 rounded px-2.5 py-1.5 text-neutral-200"
                />
              </div>

              <div className="flex items-end">
                <button
                  type="submit"
                  className="w-full py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded font-medium transition-colors"
                >
                  Add Synonym Rule
                </button>
              </div>
            </form>
          </div>

          {/* Live Synonym Simulator */}
          <div className="bg-neutral-900/40 border border-neutral-800 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="text-neutral-400 font-mono text-[11px]">Test Synonym Expansion:</span>
              <input
                type="text"
                value={synonymTestWord}
                onChange={(e) => setSynonymTestWord(e.target.value)}
                placeholder="type word e.g. phone"
                className="bg-neutral-950 border border-neutral-800 rounded px-2 py-1 text-neutral-200 font-mono text-xs w-36"
              />
            </div>
            <div className="flex items-center gap-1.5 overflow-x-auto text-[11px]">
              <span className="text-neutral-500">Expands to:</span>
              {expandedSynonymList.length > 0 ? (
                expandedSynonymList.map((term) => (
                  <span
                    key={term}
                    className="bg-cyan-950/60 border border-cyan-800/40 text-cyan-300 px-2 py-0.5 rounded font-mono"
                  >
                    {term}
                  </span>
                ))
              ) : (
                <span className="text-neutral-500 italic">No synonyms matched for this word</span>
              )}
            </div>
          </div>

          {/* Synonyms Table */}
          <div className="bg-neutral-900/60 border border-neutral-800 rounded-xl p-5 space-y-3">
            <h3 className="text-sm font-semibold text-neutral-200">Configured Synonyms</h3>
            <div className="space-y-2">
              {schema.relevance.synonyms.map((syn) => (
                <div
                  key={syn.id}
                  className="bg-neutral-950 border border-neutral-800 rounded-lg p-3 flex items-center justify-between"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-[11px] text-cyan-400 uppercase">
                        {syn.type}
                      </span>
                      {syn.rootTerm && (
                        <span className="text-neutral-300">
                          Root: <strong className="text-white">{syn.rootTerm}</strong> &rarr;
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-1.5 flex-wrap">
                      {syn.terms.map((t) => (
                        <span
                          key={t}
                          className="bg-neutral-900 border border-neutral-800 px-2 py-0.5 rounded font-mono text-[11px] text-neutral-300"
                        >
                          {t}
                        </span>
                      ))}
                    </div>
                  </div>

                  <button
                    onClick={() => handleRemoveSynonym(syn.id)}
                    className="p-1 text-neutral-500 hover:text-rose-400 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab 5: Merchandising Rules */}
      {activeSubTab === 'rules' && (
        <div className="space-y-5 text-xs">
          {/* Add Merchandising Rule */}
          <div className="bg-neutral-900/60 border border-neutral-800 rounded-xl p-5 space-y-4">
            <h3 className="text-sm font-semibold text-neutral-200 flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-amber-400" />
              Create Merchandising Rule
            </h3>

            <form onSubmit={handleAddRule} className="grid grid-cols-1 md:grid-cols-4 gap-3">
              <div>
                <label className="text-neutral-400 font-mono text-[11px] block mb-1">
                  Rule Name:
                </label>
                <input
                  type="text"
                  value={newRuleName}
                  onChange={(e) => setNewRuleName(e.target.value)}
                  placeholder="e.g. Pin iPhone on 'apple'"
                  className="w-full bg-neutral-950 border border-neutral-800 rounded px-2.5 py-1.5 text-neutral-200"
                />
              </div>

              <div>
                <label className="text-neutral-400 font-mono text-[11px] block mb-1">
                  Trigger Query (Exact):
                </label>
                <input
                  type="text"
                  value={newRuleQuery}
                  onChange={(e) => setNewRuleQuery(e.target.value)}
                  placeholder="e.g. apple"
                  className="w-full bg-neutral-950 border border-neutral-800 rounded px-2.5 py-1.5 text-neutral-200 font-mono"
                />
              </div>

              <div>
                <label className="text-neutral-400 font-mono text-[11px] block mb-1">
                  Pin Document to #1:
                </label>
                <select
                  value={newRulePinDocId}
                  onChange={(e) => setNewRulePinDocId(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded px-2.5 py-1.5 text-neutral-200"
                >
                  {documentList.map((doc) => (
                    <option key={doc.id} value={doc.id}>
                      {doc.title || doc.name || doc.id}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-end">
                <button
                  type="submit"
                  className="w-full py-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded font-medium transition-colors"
                >
                  Create Rule
                </button>
              </div>
            </form>
          </div>

          {/* Active Rules List */}
          <div className="bg-neutral-900/60 border border-neutral-800 rounded-xl p-5 space-y-3">
            <h3 className="text-sm font-semibold text-neutral-200">Configured Rules</h3>
            <div className="space-y-2">
              {schema.relevance.rules.length === 0 && (
                <div className="text-neutral-500 italic p-4 text-center">
                  No merchandising rules configured yet.
                </div>
              )}
              {schema.relevance.rules.map((rule) => (
                <div
                  key={rule.id}
                  className="bg-neutral-950 border border-neutral-800 rounded-lg p-3.5 flex items-center justify-between"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-neutral-200">{rule.name}</span>
                      <span
                        className={`text-[10px] font-mono px-2 py-0.5 rounded ${
                          rule.enabled ? 'bg-emerald-500/10 text-emerald-400' : 'bg-neutral-800 text-neutral-500'
                        }`}
                      >
                        {rule.enabled ? 'ACTIVE' : 'PAUSED'}
                      </span>
                    </div>
                    <div className="text-[11px] text-neutral-400 flex items-center gap-2">
                      <span>Condition: Query is &quot;{rule.condition.value}&quot;</span>
                      <span>&rarr;</span>
                      {rule.action.pinDocId && (
                        <span>Pin doc [{rule.action.pinDocId}] to position #{rule.action.pinPosition || 1}</span>
                      )}
                      {rule.action.boostCategory && (
                        <span>Boost category [{rule.action.boostCategory}]</span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleToggleRule(rule.id)}
                      className="px-2.5 py-1 text-[11px] bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 rounded text-neutral-300"
                    >
                      {rule.enabled ? 'Pause' : 'Enable'}
                    </button>
                    <button
                      onClick={() => handleRemoveRule(rule.id)}
                      className="p-1 text-neutral-500 hover:text-rose-400 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab 6: Vector & HNSW Config */}
      {activeSubTab === 'vector' && (
        <div className="bg-neutral-900/60 border border-neutral-800 rounded-xl p-5 space-y-5 text-xs">
          <div>
            <h3 className="text-sm font-semibold text-neutral-200 flex items-center gap-1.5">
              <Compass className="w-4 h-4 text-purple-400" />
              Dense Vector &amp; Hybrid Retrieval Parameters
            </h3>
            <p className="text-neutral-400 mt-1">
              Configure vector embedding dimensions, distance similarity metrics (HNSW indexing), and default Reciprocal Rank Fusion constants.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-4 bg-neutral-950 border border-neutral-800 rounded-lg space-y-1.5">
              <span className="font-mono text-[11px] text-neutral-400">Vector Dimension</span>
              <div className="text-lg font-bold font-mono text-purple-300">
                {schema.vectorDimension || 64}-dim
              </div>
              <p className="text-[11px] text-neutral-500">
                Dense hypersphere coordinate dimension for semantic text representations.
              </p>
            </div>

            <div className="p-4 bg-neutral-950 border border-neutral-800 rounded-lg space-y-1.5">
              <span className="font-mono text-[11px] text-neutral-400">Distance Metric</span>
              <div className="text-lg font-bold font-mono text-cyan-300 uppercase">
                {schema.distanceMetric}
              </div>
              <p className="text-[11px] text-neutral-500">
                Cosine angle similarity for semantic text and document vector comparison.
              </p>
            </div>

            <div className="p-4 bg-neutral-950 border border-neutral-800 rounded-lg space-y-1.5">
              <span className="font-mono text-[11px] text-neutral-400">RRF Constant (k)</span>
              <div className="text-lg font-bold font-mono text-neutral-200">
                k = {schema.relevance.hybridConfig.rrfK || 60}
              </div>
              <p className="text-[11px] text-neutral-500">
                Reciprocal Rank Fusion smoothing parameter for merging BM25 and vector lists.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
