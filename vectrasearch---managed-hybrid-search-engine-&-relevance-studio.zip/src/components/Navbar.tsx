import React from 'react';
import { Search, Sliders, Database, BarChart3, Key, Plus, RefreshCw } from 'lucide-react';
import { IndexSchema } from '../engine/types';

interface NavbarProps {
  activeTab: 'studio' | 'relevance' | 'inspector' | 'analytics' | 'api';
  setActiveTab: (tab: 'studio' | 'relevance' | 'inspector' | 'analytics' | 'api') => void;
  indexes: IndexSchema[];
  currentIndexId: string;
  onSelectIndex: (id: string) => void;
  onResetData: () => void;
  onNewIndexModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  indexes,
  currentIndexId,
  onSelectIndex,
  onResetData,
  onNewIndexModal,
}) => {
  return (
    <header className="border-b border-neutral-800 bg-neutral-950/80 backdrop-blur-md sticky top-0 z-40 px-5 py-2.5">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        {/* Zone 1: Single text element wordmark */}
        <div className="flex items-center gap-3">
          <a
            href="#"
            onClick={(e) => {
              e.preventDefault();
              setActiveTab('studio');
            }}
            className="text-lg font-bold tracking-tight text-white flex items-center gap-2"
          >
            <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 inline-block shadow-[0_0_10px_rgba(6,182,212,0.8)]" />
            VectraSearch
          </a>
          <span className="hidden sm:inline-block text-xs font-mono text-neutral-500 border-l border-neutral-800 pl-3">
            v3.2·managed
          </span>
        </div>

        {/* Zone 2: 4-6 text navigation links */}
        <nav className="hidden md:flex items-center gap-1">
          <button
            onClick={() => setActiveTab('studio')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              activeTab === 'studio'
                ? 'bg-neutral-800 text-cyan-300 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900'
            }`}
          >
            <Search className="w-3.5 h-3.5" />
            Search Studio
          </button>

          <button
            onClick={() => setActiveTab('relevance')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              activeTab === 'relevance'
                ? 'bg-neutral-800 text-cyan-300 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            Relevance Tuning
          </button>

          <button
            onClick={() => setActiveTab('inspector')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              activeTab === 'inspector'
                ? 'bg-neutral-800 text-cyan-300 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900'
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            Index Inspector
          </button>

          <button
            onClick={() => setActiveTab('analytics')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              activeTab === 'analytics'
                ? 'bg-neutral-800 text-cyan-300 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            Analytics & Telemetry
          </button>

          <button
            onClick={() => setActiveTab('api')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              activeTab === 'api'
                ? 'bg-neutral-800 text-cyan-300 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900'
            }`}
          >
            <Key className="w-3.5 h-3.5" />
            API & SDKs
          </button>
        </nav>

        {/* Zone 3: 1-2 primary actions & index switcher */}
        <div className="flex items-center gap-2">
          {/* Index Selector */}
          <div className="flex items-center bg-neutral-900 border border-neutral-800 rounded-md px-2 py-1 text-xs">
            <span className="text-neutral-500 mr-1.5 text-[11px] hidden sm:inline">Index:</span>
            <select
              value={currentIndexId}
              onChange={(e) => onSelectIndex(e.target.value)}
              className="bg-transparent text-neutral-200 font-medium focus:outline-none cursor-pointer pr-1 text-xs"
            >
              {indexes.map((idx) => (
                <option key={idx.id} value={idx.id} className="bg-neutral-900 text-neutral-200">
                  {idx.name} ({idx.id})
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={onNewIndexModal}
            title="Create New Index"
            className="p-1.5 text-neutral-400 hover:text-white hover:bg-neutral-800 rounded-md border border-neutral-800 transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={onResetData}
            title="Reset Index to Demo Data"
            className="p-1.5 text-neutral-400 hover:text-white hover:bg-neutral-800 rounded-md border border-neutral-800 transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Mobile nav pills */}
      <div className="md:hidden flex items-center gap-1 overflow-x-auto pt-2 pb-1 border-t border-neutral-800/60 mt-2">
        <button
          onClick={() => setActiveTab('studio')}
          className={`px-2.5 py-1 text-xs rounded-md whitespace-nowrap ${
            activeTab === 'studio' ? 'bg-neutral-800 text-cyan-300 font-medium' : 'text-neutral-400'
          }`}
        >
          Studio
        </button>
        <button
          onClick={() => setActiveTab('relevance')}
          className={`px-2.5 py-1 text-xs rounded-md whitespace-nowrap ${
            activeTab === 'relevance' ? 'bg-neutral-800 text-cyan-300 font-medium' : 'text-neutral-400'
          }`}
        >
          Relevance
        </button>
        <button
          onClick={() => setActiveTab('inspector')}
          className={`px-2.5 py-1 text-xs rounded-md whitespace-nowrap ${
            activeTab === 'inspector' ? 'bg-neutral-800 text-cyan-300 font-medium' : 'text-neutral-400'
          }`}
        >
          Inspector
        </button>
        <button
          onClick={() => setActiveTab('analytics')}
          className={`px-2.5 py-1 text-xs rounded-md whitespace-nowrap ${
            activeTab === 'analytics' ? 'bg-neutral-800 text-cyan-300 font-medium' : 'text-neutral-400'
          }`}
        >
          Analytics
        </button>
        <button
          onClick={() => setActiveTab('api')}
          className={`px-2.5 py-1 text-xs rounded-md whitespace-nowrap ${
            activeTab === 'api' ? 'bg-neutral-800 text-cyan-300 font-medium' : 'text-neutral-400'
          }`}
        >
          API & SDKs
        </button>
      </div>
    </header>
  );
};
