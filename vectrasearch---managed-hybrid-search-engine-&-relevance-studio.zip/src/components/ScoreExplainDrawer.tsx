import React from 'react';
import { X, Sparkles, Zap, Hash, Compass, ArrowUpRight } from 'lucide-react';
import { SearchResultHit } from '../engine/types';

interface ScoreExplainDrawerProps {
  hit: SearchResultHit | null;
  onClose: () => void;
  query: string;
}

export const ScoreExplainDrawer: React.FC<ScoreExplainDrawerProps> = ({ hit, onClose, query }) => {
  if (!hit) return null;

  const { breakdown, document } = hit;
  const vector = Array.isArray(document._vector) ? document._vector : [];

  return (
    <div className="fixed inset-y-0 right-0 w-full sm:w-[460px] bg-neutral-900/95 backdrop-blur-xl border-l border-neutral-800 z-50 shadow-2xl flex flex-col animate-in slide-in-from-right duration-200">
      {/* Header */}
      <div className="px-5 py-4 border-b border-neutral-800 flex items-center justify-between">
        <div>
          <div className="text-xs font-mono uppercase tracking-wider text-cyan-400 font-semibold flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5" />
            Relevance Score Breakdown
          </div>
          <h3 className="text-sm font-semibold text-neutral-100 truncate mt-0.5 max-w-[340px]">
            {document.title || document.name || document.id}
          </h3>
        </div>
        <button
          onClick={onClose}
          className="p-1 text-neutral-400 hover:text-white hover:bg-neutral-800 rounded transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Body */}
      <div className="flex-1 overflow-y-auto p-5 space-y-5 text-xs text-neutral-300">
        {/* Total Score Banner */}
        <div className="bg-neutral-950 border border-neutral-800 rounded-lg p-3.5 flex items-center justify-between">
          <div>
            <div className="text-[11px] text-neutral-400 uppercase tracking-wider font-mono">Final Combined Score</div>
            <div className="text-2xl font-bold font-mono text-cyan-300 tabular-nums">
              {hit.score.toFixed(3)}
            </div>
          </div>
          {breakdown.isPinned && (
            <div className="bg-amber-500/10 border border-amber-500/30 text-amber-300 px-2.5 py-1 rounded text-[11px] font-medium flex items-center gap-1">
              <Zap className="w-3 h-3 text-amber-400" />
              Pinned to #{breakdown.pinPosition || 1}
            </div>
          )}
        </div>

        {/* Explain Formula */}
        <div>
          <h4 className="text-[11px] font-semibold uppercase tracking-wider text-neutral-400 mb-2 font-mono">
            Ranking Equation
          </h4>
          <div className="bg-neutral-950 border border-neutral-850 p-2.5 rounded text-[11px] font-mono text-neutral-300 overflow-x-auto">
            <code>
              Score = (1 - &alpha;) &times; Norm(BM25) + &alpha; &times; VectorCosine + CustomBoost - TypoPenalty
            </code>
          </div>
        </div>

        {/* Breakdown Items */}
        <div className="space-y-2.5">
          <h4 className="text-[11px] font-semibold uppercase tracking-wider text-neutral-400 font-mono">
            Individual Signal Contributions
          </h4>

          {/* BM25 Sparse Score */}
          <div className="bg-neutral-950/70 border border-neutral-800/80 rounded-lg p-3 space-y-1">
            <div className="flex items-center justify-between">
              <span className="font-medium text-neutral-200 flex items-center gap-1.5">
                <Hash className="w-3.5 h-3.5 text-blue-400" />
                BM25 Keyword Score
              </span>
              <span className="font-mono font-semibold text-blue-400 tabular-nums">
                +{breakdown.bm25Score.toFixed(2)}
              </span>
            </div>
            <p className="text-[11px] text-neutral-400">
              Evaluated term frequency (TF), inverse document frequency (IDF) and field weights across{' '}
              <span className="text-neutral-200">{breakdown.matchedFields.join(', ') || 'none'}</span>.
            </p>
          </div>

          {/* Vector Cosine Score */}
          <div className="bg-neutral-950/70 border border-neutral-800/80 rounded-lg p-3 space-y-1">
            <div className="flex items-center justify-between">
              <span className="font-medium text-neutral-200 flex items-center gap-1.5">
                <Compass className="w-3.5 h-3.5 text-purple-400" />
                Vector Cosine Similarity
              </span>
              <span className="font-mono font-semibold text-purple-400 tabular-nums">
                +{breakdown.vectorScore.toFixed(4)}
              </span>
            </div>
            <p className="text-[11px] text-neutral-400">
              Dot product on 64-dimensional normalized hypersphere between query vector &quot;{query}&quot; and document embedding.
            </p>
          </div>

          {/* Exact Match Bonus */}
          {breakdown.exactMatchBonus > 0 && (
            <div className="bg-neutral-950/70 border border-neutral-800/80 rounded-lg p-3 space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-medium text-neutral-200">Exact Phrase Match Bonus</span>
                <span className="font-mono font-semibold text-emerald-400 tabular-nums">
                  +{breakdown.exactMatchBonus.toFixed(2)}
                </span>
              </div>
              <p className="text-[11px] text-neutral-400">
                Full unbroken query token sequence was matched verbatim in searchable attributes.
              </p>
            </div>
          )}

          {/* Custom Ranking Boost */}
          {breakdown.customRankBoost > 0 && (
            <div className="bg-neutral-950/70 border border-neutral-800/80 rounded-lg p-3 space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-medium text-neutral-200 flex items-center gap-1.5">
                  <ArrowUpRight className="w-3.5 h-3.5 text-cyan-400" />
                  Custom Business Boost
                </span>
                <span className="font-mono font-semibold text-cyan-400 tabular-nums">
                  +{breakdown.customRankBoost.toFixed(2)}
                </span>
              </div>
              <p className="text-[11px] text-neutral-400">
                Calculated from secondary tie-breaking attributes (sales count, rating, views or merchandising boost).
              </p>
            </div>
          )}

          {/* Typo Penalty */}
          {breakdown.typoPenalty > 0 && (
            <div className="bg-neutral-950/70 border border-neutral-800/80 rounded-lg p-3 space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-medium text-neutral-200">Fuzzy Typo Distance Penalty</span>
                <span className="font-mono font-semibold text-rose-400 tabular-nums">
                  -{breakdown.typoPenalty.toFixed(2)}
                </span>
              </div>
              <p className="text-[11px] text-neutral-400">
                Matched via Damerau-Levenshtein edit distance (typo substitution/transposition).
              </p>
            </div>
          )}
        </div>

        {/* Vector Embedding Visualizer */}
        {vector.length > 0 && (
          <div>
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-[11px] font-semibold uppercase tracking-wider text-neutral-400 font-mono">
                Document Vector Embeddings (64-dim)
              </h4>
              <span className="text-[10px] text-neutral-500 font-mono">Unit L2 Norm = 1.0</span>
            </div>
            <div className="bg-neutral-950 border border-neutral-800 p-3 rounded-lg">
              <div className="grid grid-cols-16 gap-1 h-12 items-end mb-2">
                {vector.slice(0, 32).map((val, idx) => {
                  const heightPct = Math.min(100, Math.max(10, Math.abs(val) * 200));
                  const isPositive = val >= 0;
                  return (
                    <div
                      key={idx}
                      title={`Dim ${idx}: ${val}`}
                      style={{ height: `${heightPct}%` }}
                      className={`w-full rounded-xs transition-all ${
                        isPositive ? 'bg-cyan-500/70 hover:bg-cyan-400' : 'bg-purple-500/70 hover:bg-purple-400'
                      }`}
                    />
                  );
                })}
              </div>
              <div className="font-mono text-[10px] text-neutral-400 truncate">
                [{vector.slice(0, 8).map((v) => v.toFixed(3)).join(', ')}, ...]
              </div>
            </div>
          </div>
        )}

        {/* Raw JSON Data Preview */}
        <div>
          <h4 className="text-[11px] font-semibold uppercase tracking-wider text-neutral-400 mb-2 font-mono">
            Document Attributes
          </h4>
          <pre className="bg-neutral-950 border border-neutral-800 p-3 rounded-lg text-[10px] font-mono text-neutral-300 overflow-x-auto max-h-48">
            {JSON.stringify(
              Object.fromEntries(Object.entries(document).filter(([k]) => k !== '_vector')),
              null,
              2
            )}
          </pre>
        </div>
      </div>
    </div>
  );
};
