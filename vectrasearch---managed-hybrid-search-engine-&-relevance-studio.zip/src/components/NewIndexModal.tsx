import React, { useState } from 'react';
import { Database, X } from 'lucide-react';
import { IndexSchema } from '../engine/types';

interface NewIndexModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreate: (newIndex: IndexSchema) => void;
}

export const NewIndexModal: React.FC<NewIndexModalProps> = ({
  isOpen,
  onClose,
  onCreate,
}) => {
  const [indexId, setIndexId] = useState('');
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [vectorDimension, setVectorDimension] = useState(64);
  const [distanceMetric, setDistanceMetric] = useState<'cosine' | 'dot_product' | 'euclidean'>('cosine');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!indexId.trim()) return;

    const cleanId = indexId.trim().toLowerCase().replace(/[^\w-]/g, '_');
    const newSchema: IndexSchema = {
      id: cleanId,
      name: name.trim() || cleanId,
      description: description.trim() || 'Custom managed hybrid index',
      primaryKey: 'id',
      vectorDimension,
      distanceMetric,
      createdAt: new Date().toISOString(),
      fields: [
        { name: 'title', type: 'string', searchable: true, filterable: false, sortable: true, boost: 10 },
        { name: 'category', type: 'string', searchable: true, filterable: true, sortable: true, boost: 5 },
        { name: 'description', type: 'string', searchable: true, filterable: false, sortable: false, boost: 2 },
        { name: 'price', type: 'number', searchable: false, filterable: true, sortable: true, boost: 1 },
        { name: '_vector', type: 'vector', searchable: true, filterable: false, sortable: false, boost: 1 },
      ],
      relevance: {
        searchableAttributes: [
          { field: 'title', weight: 10 },
          { field: 'category', weight: 5 },
          { field: 'description', weight: 2 },
        ],
        customRanking: [{ field: 'price', order: 'asc' }],
        typoTolerance: {
          enabled: true,
          minWordSizeForOneTypo: 4,
          minWordSizeForTwoTypos: 8,
          disableOnFields: [],
        },
        synonyms: [],
        rules: [],
        hybridConfig: {
          mode: 'hybrid',
          alpha: 0.5,
          rrfK: 60,
        },
        prefixSearch: 'last_word',
      },
    };

    onCreate(newSchema);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-neutral-900 border border-neutral-800 rounded-xl w-full max-w-md shadow-2xl p-5 space-y-4 text-xs">
        <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
          <h3 className="text-sm font-semibold text-neutral-100 flex items-center gap-1.5">
            <Database className="w-4 h-4 text-cyan-400" />
            Provision New Managed Index
          </h3>
          <button onClick={onClose} className="text-neutral-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <label className="text-neutral-400 font-mono text-[11px] block mb-1">Index ID (Slug):</label>
            <input
              type="text"
              required
              value={indexId}
              onChange={(e) => setIndexId(e.target.value)}
              placeholder="e.g. blog_posts or customer_tickets"
              className="w-full bg-neutral-950 border border-neutral-800 rounded px-3 py-1.5 text-neutral-200 font-mono"
            />
          </div>

          <div>
            <label className="text-neutral-400 font-mono text-[11px] block mb-1">Display Name:</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Support Knowledge Base"
              className="w-full bg-neutral-950 border border-neutral-800 rounded px-3 py-1.5 text-neutral-200"
            />
          </div>

          <div>
            <label className="text-neutral-400 font-mono text-[11px] block mb-1">Description:</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={2}
              placeholder="What kind of records will this index store?"
              className="w-full bg-neutral-950 border border-neutral-800 rounded px-3 py-1.5 text-neutral-200"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-neutral-400 font-mono text-[11px] block mb-1">
                Vector Dimension:
              </label>
              <select
                value={vectorDimension}
                onChange={(e) => setVectorDimension(parseInt(e.target.value))}
                className="w-full bg-neutral-950 border border-neutral-800 rounded px-3 py-1.5 text-neutral-200 font-mono"
              >
                <option value={64}>64-dim (Fast local)</option>
                <option value={384}>384-dim (MiniLM)</option>
                <option value={768}>768-dim (Standard)</option>
                <option value={1536}>1536-dim (High-res)</option>
              </select>
            </div>

            <div>
              <label className="text-neutral-400 font-mono text-[11px] block mb-1">
                Distance Metric:
              </label>
              <select
                value={distanceMetric}
                onChange={(e) => setDistanceMetric(e.target.value as any)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded px-3 py-1.5 text-neutral-200 font-mono"
              >
                <option value="cosine">Cosine</option>
                <option value="dot_product">Dot Product</option>
                <option value="euclidean">Euclidean L2</option>
              </select>
            </div>
          </div>

          <div className="pt-2 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 bg-neutral-800 text-neutral-300 rounded hover:bg-neutral-700"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 bg-cyan-600 text-white rounded font-medium hover:bg-cyan-500"
            >
              Provision Index
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
