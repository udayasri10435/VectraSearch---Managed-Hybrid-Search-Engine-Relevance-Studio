import React, { useState } from 'react';
import {
  BarChart3,
  TrendingUp,
  Clock,
  MousePointerClick,
  AlertTriangle,
  ArrowUpRight,
  Plus,
  Zap,
  Tag,
  Check,
} from 'lucide-react';
import { AnalyticsTracker, AnalyticsSummary } from '../engine/analyticsStore';
import { IndexSchema } from '../engine/types';

interface AnalyticsViewProps {
  analytics: AnalyticsTracker;
  schema: IndexSchema;
  onQuickAddSynonym: (query: string) => void;
  onQuickAddRule: (query: string) => void;
}

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({
  analytics,
  schema,
  onQuickAddSynonym,
  onQuickAddRule,
}) => {
  const summary: AnalyticsSummary = analytics.getSummary();
  const [copiedQuery, setCopiedQuery] = useState<string | null>(null);

  const handleCopy = (q: string) => {
    navigator.clipboard.writeText(q);
    setCopiedQuery(q);
    setTimeout(() => setCopiedQuery(null), 1500);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-neutral-800">
        <div>
          <h2 className="text-lg font-bold text-neutral-100 flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-cyan-400" />
            Search Analytics &amp; Query Telemetry
          </h2>
          <p className="text-xs text-neutral-400 mt-0.5">
            Real-time query performance metrics, click-through rates, and zero-result queries to optimize search relevance.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-neutral-400 bg-neutral-900 border border-neutral-800 px-3 py-1.5 rounded-lg">
          <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block animate-pulse" />
          <span>Real-time Stream: Active</span>
        </div>
      </div>

      {/* KPI Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
        {/* Total Searches */}
        <div className="bg-neutral-900/60 border border-neutral-800 rounded-xl p-4 space-y-1.5">
          <div className="flex items-center justify-between text-neutral-400 font-mono text-[11px]">
            <span>Total Queries</span>
            <TrendingUp className="w-3.5 h-3.5 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-neutral-100 tabular-nums">
            {summary.totalQueries.toLocaleString()}
          </div>
          <p className="text-[11px] text-neutral-500">
            Across live simulator and API calls
          </p>
        </div>

        {/* Avg Latency */}
        <div className="bg-neutral-900/60 border border-neutral-800 rounded-xl p-4 space-y-1.5">
          <div className="flex items-center justify-between text-neutral-400 font-mono text-[11px]">
            <span>Avg Query Latency</span>
            <Clock className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-emerald-400 tabular-nums">
            {summary.avgLatencyMs.toFixed(1)} ms
          </div>
          <p className="text-[11px] text-neutral-500">
            Sub-millisecond BM25 + Vector cosine
          </p>
        </div>

        {/* Click Through Rate */}
        <div className="bg-neutral-900/60 border border-neutral-800 rounded-xl p-4 space-y-1.5">
          <div className="flex items-center justify-between text-neutral-400 font-mono text-[11px]">
            <span>Click-Through Rate (CTR)</span>
            <MousePointerClick className="w-3.5 h-3.5 text-purple-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-purple-300 tabular-nums">
            {summary.ctrPercent}%
          </div>
          <p className="text-[11px] text-neutral-500">
            {summary.totalClicks.toLocaleString()} item clicks logged
          </p>
        </div>

        {/* Zero Hit Rate */}
        <div className="bg-neutral-900/60 border border-neutral-800 rounded-xl p-4 space-y-1.5">
          <div className="flex items-center justify-between text-neutral-400 font-mono text-[11px]">
            <span>Zero-Result Rate</span>
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-amber-300 tabular-nums">
            {summary.zeroHitRatePercent}%
          </div>
          <p className="text-[11px] text-neutral-500">
            Unserved user intents to remediate
          </p>
        </div>
      </div>

      {/* Latency Percentiles & Hourly Traffic Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Latency Percentiles */}
        <div className="bg-neutral-900/60 border border-neutral-800 rounded-xl p-5 space-y-4 text-xs">
          <h3 className="font-semibold text-neutral-200 uppercase font-mono tracking-wider text-[11px]">
            Latency Percentile Distribution
          </h3>

          <div className="space-y-3">
            <div className="bg-neutral-950 border border-neutral-800 rounded-lg p-3 flex items-center justify-between">
              <div>
                <span className="font-mono text-neutral-400">P50 (Median)</span>
                <p className="text-[11px] text-neutral-500">50% of searches finish within</p>
              </div>
              <span className="font-mono text-base font-bold text-cyan-400 tabular-nums">
                {summary.p50LatencyMs.toFixed(1)} ms
              </span>
            </div>

            <div className="bg-neutral-950 border border-neutral-800 rounded-lg p-3 flex items-center justify-between">
              <div>
                <span className="font-mono text-neutral-400">P95 (95th Percentile)</span>
                <p className="text-[11px] text-neutral-500">95% of searches finish within</p>
              </div>
              <span className="font-mono text-base font-bold text-emerald-400 tabular-nums">
                {summary.p95LatencyMs.toFixed(1)} ms
              </span>
            </div>

            <div className="bg-neutral-950 border border-neutral-800 rounded-lg p-3 flex items-center justify-between">
              <div>
                <span className="font-mono text-neutral-400">P99 (Tail Latency)</span>
                <p className="text-[11px] text-neutral-500">99% of complex hybrid queries</p>
              </div>
              <span className="font-mono text-base font-bold text-purple-400 tabular-nums">
                {summary.p99LatencyMs.toFixed(1)} ms
              </span>
            </div>
          </div>
        </div>

        {/* Hourly Volume Histogram */}
        <div className="lg:col-span-2 bg-neutral-900/60 border border-neutral-800 rounded-xl p-5 space-y-4 text-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-neutral-200 uppercase font-mono tracking-wider text-[11px]">
              Query Throughput Volume (24h Window)
            </h3>
            <span className="font-mono text-[11px] text-neutral-500">Peak: 210 req/hr</span>
          </div>

          {/* Bar Chart Representation */}
          <div className="grid grid-cols-8 gap-2.5 h-36 items-end pt-4">
            {summary.hourlyTraffic.map((bucket) => {
              const heightPct = Math.min(100, Math.max(15, (bucket.queries / 220) * 100));
              return (
                <div key={bucket.hour} className="flex flex-col items-center gap-1.5 h-full justify-end group">
                  <span className="font-mono text-[10px] text-neutral-400 tabular-nums opacity-0 group-hover:opacity-100 transition-opacity">
                    {bucket.queries}
                  </span>
                  <div
                    style={{ height: `${heightPct}%` }}
                    className="w-full bg-cyan-500/30 group-hover:bg-cyan-400 border-t border-cyan-400 rounded-t-xs transition-colors"
                  />
                  <span className="font-mono text-[10px] text-neutral-500">
                    {bucket.hour}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Zero-Hit Queries Table (Critical Algolia/Typesense relevance feature) */}
      <div className="bg-neutral-900/60 border border-neutral-800 rounded-xl p-5 space-y-4 text-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="font-semibold text-neutral-200 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              Zero-Hit Queries (Unfulfilled Intent)
            </h3>
            <p className="text-neutral-400 text-[11px] mt-0.5">
              These searches returned zero results. Click &quot;Add Synonym&quot; or &quot;Pin Rule&quot; to immediately fix relevance for these queries!
            </p>
          </div>

          <span className="font-mono text-neutral-500 text-[11px]">
            {summary.zeroHitQueries.length} zero-hit patterns detected
          </span>
        </div>

        {summary.zeroHitQueries.length === 0 ? (
          <div className="p-8 text-center text-neutral-500 italic bg-neutral-950/40 rounded-lg">
            No zero-hit queries recorded yet. Excellent catalog coverage!
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-neutral-800 text-[11px] font-mono text-neutral-400">
                  <th className="py-2.5 px-3">Failed Search Query</th>
                  <th className="py-2.5 px-3">Occurrence Count</th>
                  <th className="py-2.5 px-3">Last Seen</th>
                  <th className="py-2.5 px-3 text-right">Instant Remediation Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-800/60">
                {summary.zeroHitQueries.map((item) => (
                  <tr key={item.query} className="hover:bg-neutral-850/40 transition-colors">
                    <td className="py-2.5 px-3 font-mono text-amber-300 font-semibold">
                      &quot;{item.query}&quot;
                    </td>

                    <td className="py-2.5 px-3 font-mono text-neutral-300 tabular-nums">
                      {item.count} searches
                    </td>

                    <td className="py-2.5 px-3 font-mono text-neutral-500">
                      {item.lastOccurred}
                    </td>

                    <td className="py-2.5 px-3 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => onQuickAddSynonym(item.query)}
                          className="px-2.5 py-1 text-[11px] bg-cyan-950/60 border border-cyan-800/60 hover:bg-cyan-900/60 text-cyan-300 rounded font-medium flex items-center gap-1 transition-colors"
                        >
                          <Tag className="w-3 h-3" />
                          Add Synonym
                        </button>

                        <button
                          onClick={() => onQuickAddRule(item.query)}
                          className="px-2.5 py-1 text-[11px] bg-amber-950/60 border border-amber-800/60 hover:bg-amber-900/60 text-amber-300 rounded font-medium flex items-center gap-1 transition-colors"
                        >
                          <Zap className="w-3 h-3" />
                          Create Rule
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Top Queries Table */}
      <div className="bg-neutral-900/60 border border-neutral-800 rounded-xl p-5 space-y-4 text-xs">
        <h3 className="font-semibold text-neutral-200 uppercase font-mono tracking-wider text-[11px]">
          Most Frequent Search Queries
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-neutral-800 text-[11px] font-mono text-neutral-400">
                <th className="py-2.5 px-3">Query</th>
                <th className="py-2.5 px-3">Volume</th>
                <th className="py-2.5 px-3">Avg Hits</th>
                <th className="py-2.5 px-3">CTR</th>
                <th className="py-2.5 px-3 text-right">Avg Latency</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800/60 font-sans">
              {summary.topQueries.map((q) => (
                <tr key={q.query} className="hover:bg-neutral-850/40 transition-colors">
                  <td className="py-2.5 px-3 font-mono font-medium text-neutral-200">
                    {q.query}
                  </td>

                  <td className="py-2.5 px-3 font-mono text-neutral-300 tabular-nums">
                    {q.count}
                  </td>

                  <td className="py-2.5 px-3 font-mono text-neutral-400 tabular-nums">
                    {q.avgHits}
                  </td>

                  <td className="py-2.5 px-3 font-mono text-purple-300 tabular-nums font-semibold">
                    {q.ctr}%
                  </td>

                  <td className="py-2.5 px-3 font-mono text-cyan-400 tabular-nums text-right">
                    {q.avgLatency} ms
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
