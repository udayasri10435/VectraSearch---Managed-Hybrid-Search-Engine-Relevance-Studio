import React, { useState } from 'react';
import {
  Database,
  Plus,
  Trash2,
  Edit,
  Download,
  Upload,
  Search,
  Check,
  X,
  FileCode,
  Layers,
  Sparkles,
} from 'lucide-react';
import { IndexSchema, DocumentRecord } from '../engine/types';

interface IndexInspectorProps {
  schema: IndexSchema;
  documents: DocumentRecord[];
  onAddDocument: (doc: DocumentRecord) => void;
  onUpdateDocument: (id: string, updated: Partial<DocumentRecord>) => void;
  onDeleteDocument: (id: string) => void;
  onBatchImport: (docs: DocumentRecord[]) => void;
}

export const IndexInspector: React.FC<IndexInspectorProps> = ({
  schema,
  documents,
  onAddDocument,
  onUpdateDocument,
  onDeleteDocument,
  onBatchImport,
}) => {
  const [filterText, setFilterText] = useState('');
  const [selectedDoc, setSelectedDoc] = useState<DocumentRecord | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [jsonText, setJsonText] = useState('');
  const [jsonError, setJsonError] = useState<string | null>(null);

  // Batch import modal
  const [showImportModal, setShowImportModal] = useState(false);
  const [importJsonText, setImportJsonText] = useState('');
  const [importError, setImportError] = useState<string | null>(null);

  // New document modal
  const [showAddModal, setShowAddModal] = useState(false);
  const [newDocId, setNewDocId] = useState('');
  const [newDocTitle, setNewDocTitle] = useState('');
  const [newDocCategory, setNewDocCategory] = useState('');
  const [newDocDescription, setNewDocDescription] = useState('');
  const [newDocPrice, setNewDocPrice] = useState(199);

  // Filtered documents list
  const filteredDocs = documents.filter((doc) => {
    if (!filterText.trim()) return true;
    const q = filterText.toLowerCase();
    return (
      (doc.id && String(doc.id).toLowerCase().includes(q)) ||
      (doc.title && String(doc.title).toLowerCase().includes(q)) ||
      (doc.name && String(doc.name).toLowerCase().includes(q)) ||
      (doc.category && String(doc.category).toLowerCase().includes(q)) ||
      (doc.brand && String(doc.brand).toLowerCase().includes(q))
    );
  });

  const handleOpenDocModal = (doc: DocumentRecord) => {
    setSelectedDoc(doc);
    setIsEditing(false);
    // Exclude raw _vector from casual edit to keep it clean, but show in read-only
    const clean = { ...doc };
    setJsonText(JSON.stringify(clean, null, 2));
    setJsonError(null);
  };

  const handleSaveJsonEdit = () => {
    try {
      const parsed = JSON.parse(jsonText);
      if (!parsed.id) {
        setJsonError('Document must have an "id" field');
        return;
      }
      onUpdateDocument(parsed.id, parsed);
      setSelectedDoc(parsed);
      setIsEditing(false);
      setJsonError(null);
    } catch (e: any) {
      setJsonError(e.message || 'Invalid JSON syntax');
    }
  };

  const handleCreateDocument = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDocId.trim()) return;

    const newDoc: DocumentRecord = {
      id: newDocId.trim(),
      title: newDocTitle.trim() || 'Untitled Item',
      category: newDocCategory.trim() || 'General',
      description: newDocDescription.trim(),
      price: Number(newDocPrice) || 0,
      stock: 50,
      rating: 4.8,
    };

    onAddDocument(newDoc);
    setShowAddModal(false);
    setNewDocId('');
    setNewDocTitle('');
    setNewDocCategory('');
    setNewDocDescription('');
  };

  const handleRunBatchImport = () => {
    try {
      const parsed = JSON.parse(importJsonText);
      if (!Array.isArray(parsed)) {
        setImportError('JSON must be an array of document objects: [{ id: "...", ... }]');
        return;
      }
      onBatchImport(parsed);
      setShowImportModal(false);
      setImportJsonText('');
      setImportError(null);
    } catch (err: any) {
      setImportError(err.message || 'Failed to parse JSON array');
    }
  };

  const handleExportIndex = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(documents, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `${schema.id}_documents.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-neutral-800">
        <div>
          <h2 className="text-lg font-bold text-neutral-100 flex items-center gap-2">
            <Database className="w-5 h-5 text-cyan-400" />
            Index Inspector &amp; Document Store
          </h2>
          <p className="text-xs text-neutral-400 mt-0.5">
            Browse indexed records, edit JSON documents in place, view auto-generated vector embeddings, or batch import data.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs bg-cyan-600 hover:bg-cyan-500 text-white rounded-md font-medium transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            Add Document
          </button>

          <button
            onClick={() => setShowImportModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 rounded-md transition-colors"
          >
            <Upload className="w-3.5 h-3.5" />
            Import JSON
          </button>

          <button
            onClick={handleExportIndex}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 rounded-md transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            Export
          </button>
        </div>
      </div>

      {/* Index Summary Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
        <div className="bg-neutral-900/60 border border-neutral-800 rounded-lg p-3">
          <span className="text-neutral-500 font-mono text-[11px]">Total Documents</span>
          <div className="text-lg font-bold font-mono text-neutral-100 tabular-nums">
            {documents.length}
          </div>
        </div>

        <div className="bg-neutral-900/60 border border-neutral-800 rounded-lg p-3">
          <span className="text-neutral-500 font-mono text-[11px]">Primary Key</span>
          <div className="text-lg font-bold font-mono text-cyan-400">
            {schema.primaryKey}
          </div>
        </div>

        <div className="bg-neutral-900/60 border border-neutral-800 rounded-lg p-3">
          <span className="text-neutral-500 font-mono text-[11px]">Dense Vector Dimension</span>
          <div className="text-lg font-bold font-mono text-purple-300">
            {schema.vectorDimension}D ({schema.distanceMetric})
          </div>
        </div>

        <div className="bg-neutral-900/60 border border-neutral-800 rounded-lg p-3">
          <span className="text-neutral-500 font-mono text-[11px]">Schema Fields</span>
          <div className="text-lg font-bold font-mono text-neutral-300">
            {schema.fields.length} declared
          </div>
        </div>
      </div>

      {/* Table Search & Filter Bar */}
      <div className="flex items-center justify-between gap-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-neutral-500" />
          <input
            type="text"
            value={filterText}
            onChange={(e) => setFilterText(e.target.value)}
            placeholder="Filter records in index..."
            className="w-full bg-neutral-950 border border-neutral-800 rounded-lg pl-9 pr-3 py-1.5 text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-cyan-500"
          />
        </div>

        <span className="text-xs text-neutral-500 font-mono">
          Showing {filteredDocs.length} of {documents.length} records
        </span>
      </div>

      {/* High-Density Data Grid */}
      <div className="bg-neutral-900/60 border border-neutral-800 rounded-xl overflow-hidden text-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-neutral-950/80 border-b border-neutral-800 text-[11px] font-mono text-neutral-400">
                <th className="py-2.5 px-4 font-semibold">ID</th>
                <th className="py-2.5 px-4 font-semibold">Title / Name</th>
                <th className="py-2.5 px-4 font-semibold">Category / Section</th>
                <th className="py-2.5 px-4 font-semibold">Attributes</th>
                <th className="py-2.5 px-4 font-semibold text-center">Vector</th>
                <th className="py-2.5 px-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800/60 font-sans">
              {filteredDocs.map((doc) => {
                const hasVector = Array.isArray(doc._vector) && doc._vector.length > 0;
                return (
                  <tr
                    key={doc.id}
                    onClick={() => handleOpenDocModal(doc)}
                    className="hover:bg-neutral-850/60 cursor-pointer transition-colors group"
                  >
                    <td className="py-2.5 px-4 font-mono text-neutral-400 text-[11px] whitespace-nowrap">
                      {doc.id}
                    </td>

                    <td className="py-2.5 px-4 font-medium text-neutral-200 group-hover:text-cyan-200 transition-colors max-w-xs truncate">
                      {doc.title || doc.name || '-'}
                    </td>

                    <td className="py-2.5 px-4 text-neutral-400 whitespace-nowrap">
                      {doc.category || doc.section || doc.director || '-'}
                    </td>

                    <td className="py-2.5 px-4 text-neutral-400 font-mono text-[11px] whitespace-nowrap">
                      {doc.price !== undefined && <span>${doc.price} · </span>}
                      {doc.rating !== undefined && <span>★ {doc.rating} · </span>}
                      {doc.stock !== undefined && <span>Stock: {doc.stock}</span>}
                    </td>

                    <td className="py-2.5 px-4 text-center">
                      {hasVector ? (
                        <span className="font-mono text-[10px] text-purple-400 bg-purple-950/40 border border-purple-800/40 px-1.5 py-0.5 rounded">
                          {doc._vector.length}D
                        </span>
                      ) : (
                        <span className="text-neutral-600">-</span>
                      )}
                    </td>

                    <td className="py-2.5 px-4 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-2" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={() => handleOpenDocModal(doc)}
                          className="p-1 text-neutral-400 hover:text-white"
                          title="View / Edit JSON"
                        >
                          <FileCode className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => onDeleteDocument(doc.id)}
                          className="p-1 text-neutral-500 hover:text-rose-400"
                          title="Delete Document"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Document Inspector & JSON Editor Modal */}
      {selectedDoc && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-neutral-900 border border-neutral-800 rounded-xl w-full max-w-2xl max-h-[85vh] flex flex-col shadow-2xl animate-in zoom-in-95 duration-150">
            {/* Modal Header */}
            <div className="px-5 py-3.5 border-b border-neutral-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileCode className="w-4 h-4 text-cyan-400" />
                <h3 className="text-sm font-semibold text-neutral-100 font-mono">
                  doc_id: {selectedDoc.id}
                </h3>
              </div>
              <div className="flex items-center gap-2">
                {!isEditing ? (
                  <button
                    onClick={() => setIsEditing(true)}
                    className="px-2.5 py-1 text-xs bg-neutral-800 hover:bg-neutral-700 text-neutral-200 rounded flex items-center gap-1 transition-colors"
                  >
                    <Edit className="w-3 h-3" />
                    Edit Document
                  </button>
                ) : (
                  <button
                    onClick={handleSaveJsonEdit}
                    className="px-2.5 py-1 text-xs bg-cyan-600 hover:bg-cyan-500 text-white rounded flex items-center gap-1 transition-colors font-medium"
                  >
                    <Check className="w-3 h-3" />
                    Save Changes
                  </button>
                )}
                <button
                  onClick={() => setSelectedDoc(null)}
                  className="p-1 text-neutral-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Modal Body */}
            <div className="p-5 flex-1 overflow-y-auto space-y-3">
              {jsonError && (
                <div className="p-2.5 bg-rose-500/10 border border-rose-500/30 text-rose-300 rounded text-xs font-mono">
                  {jsonError}
                </div>
              )}

              {isEditing ? (
                <textarea
                  value={jsonText}
                  onChange={(e) => setJsonText(e.target.value)}
                  rows={16}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-lg p-3 font-mono text-xs text-neutral-200 focus:outline-none focus:border-cyan-500 resize-none"
                />
              ) : (
                <pre className="bg-neutral-950 border border-neutral-800 rounded-lg p-4 font-mono text-xs text-cyan-200 overflow-x-auto">
                  {jsonText}
                </pre>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Add Document Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-neutral-900 border border-neutral-800 rounded-xl w-full max-w-lg shadow-2xl p-5 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <h3 className="text-sm font-semibold text-neutral-100 flex items-center gap-1.5">
                <Plus className="w-4 h-4 text-cyan-400" />
                Create New Document in {schema.id}
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-neutral-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateDocument} className="space-y-3 text-xs">
              <div>
                <label className="text-neutral-400 font-mono text-[11px] block mb-1">
                  Document ID:
                </label>
                <input
                  type="text"
                  required
                  value={newDocId}
                  onChange={(e) => setNewDocId(e.target.value)}
                  placeholder="e.g. prod_99"
                  className="w-full bg-neutral-950 border border-neutral-800 rounded px-3 py-1.5 text-neutral-200 font-mono"
                />
              </div>

              <div>
                <label className="text-neutral-400 font-mono text-[11px] block mb-1">Title:</label>
                <input
                  type="text"
                  required
                  value={newDocTitle}
                  onChange={(e) => setNewDocTitle(e.target.value)}
                  placeholder="Product or document title"
                  className="w-full bg-neutral-950 border border-neutral-800 rounded px-3 py-1.5 text-neutral-200"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-neutral-400 font-mono text-[11px] block mb-1">
                    Category:
                  </label>
                  <input
                    type="text"
                    value={newDocCategory}
                    onChange={(e) => setNewDocCategory(e.target.value)}
                    placeholder="e.g. Smartphones"
                    className="w-full bg-neutral-950 border border-neutral-800 rounded px-3 py-1.5 text-neutral-200"
                  />
                </div>

                <div>
                  <label className="text-neutral-400 font-mono text-[11px] block mb-1">Price ($):</label>
                  <input
                    type="number"
                    value={newDocPrice}
                    onChange={(e) => setNewDocPrice(parseFloat(e.target.value) || 0)}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded px-3 py-1.5 text-neutral-200 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-neutral-400 font-mono text-[11px] block mb-1">
                  Description:
                </label>
                <textarea
                  value={newDocDescription}
                  onChange={(e) => setNewDocDescription(e.target.value)}
                  rows={3}
                  placeholder="Detailed description for text search and vector embeddings..."
                  className="w-full bg-neutral-950 border border-neutral-800 rounded px-3 py-1.5 text-neutral-200"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 bg-neutral-800 text-neutral-300 rounded hover:bg-neutral-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-cyan-600 text-white rounded font-medium hover:bg-cyan-500"
                >
                  Save &amp; Generate Embeddings
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Batch Import Modal */}
      {showImportModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-neutral-900 border border-neutral-800 rounded-xl w-full max-w-xl shadow-2xl p-5 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <h3 className="text-sm font-semibold text-neutral-100 flex items-center gap-1.5">
                <Upload className="w-4 h-4 text-cyan-400" />
                Batch Ingest JSON Documents
              </h3>
              <button
                onClick={() => setShowImportModal(false)}
                className="text-neutral-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-neutral-400">
              Paste a JSON array of documents. VectraSearch will automatically calculate dense vector embeddings and index all attributes in real time.
            </p>

            {importError && (
              <div className="p-2.5 bg-rose-500/10 border border-rose-500/30 text-rose-300 rounded text-xs font-mono">
                {importError}
              </div>
            )}

            <textarea
              value={importJsonText}
              onChange={(e) => setImportJsonText(e.target.value)}
              rows={8}
              placeholder={`[\n  { "id": "custom_1", "title": "Ultra Gaming Rig", "category": "Laptops", "price": 1999 }\n]`}
              className="w-full bg-neutral-950 border border-neutral-800 rounded-lg p-3 font-mono text-xs text-neutral-200 focus:outline-none focus:border-cyan-500"
            />

            <div className="flex justify-end gap-2 text-xs">
              <button
                onClick={() => setShowImportModal(false)}
                className="px-3 py-1.5 bg-neutral-800 text-neutral-300 rounded hover:bg-neutral-700"
              >
                Cancel
              </button>
              <button
                onClick={handleRunBatchImport}
                className="px-4 py-1.5 bg-cyan-600 text-white rounded font-medium hover:bg-cyan-500"
              >
                Ingest &amp; Index All
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
