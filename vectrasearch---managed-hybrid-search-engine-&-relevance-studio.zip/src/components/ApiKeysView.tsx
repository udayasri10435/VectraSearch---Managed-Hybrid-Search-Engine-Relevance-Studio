import React, { useState } from 'react';
import {
  Key,
  Plus,
  Copy,
  Check,
  Trash2,
  Terminal,
  Play,
  Code2,
  Shield,
  Layers,
} from 'lucide-react';
import { ApiKeyItem, IndexSchema } from '../engine/types';
import { SearchEngine } from '../engine/searchEngine';

interface ApiKeysViewProps {
  apiKeys: ApiKeyItem[];
  onCreateKey: (key: ApiKeyItem) => void;
  onRevokeKey: (id: string) => void;
  schema: IndexSchema;
  engine: SearchEngine;
}

export const ApiKeysView: React.FC<ApiKeysViewProps> = ({
  apiKeys,
  onCreateKey,
  onRevokeKey,
  schema,
  engine,
}) => {
  const [copiedKeyId, setCopiedKeyId] = useState<string | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newKeyName, setNewKeyName] = useState('');
  const [newKeyRole, setNewKeyRole] = useState<'admin' | 'search_only' | 'scoped'>('search_only');
  const [newKeyScope, setNewKeyScope] = useState(schema.id);
  const [newKeyRateLimit, setNewKeyRateLimit] = useState(100);

  // Interactive REST Console state
  const [requestMethod, setRequestMethod] = useState<'POST' | 'GET'>('POST');
  const [requestEndpoint, setRequestEndpoint] = useState(`/v1/indexes/${schema.id}/query`);
  const [requestBody, setRequestBody] = useState(
    JSON.stringify(
      {
        query: 'laptop',
        mode: 'hybrid',
        alpha: 0.5,
        perPage: 3,
      },
      null,
      2
    )
  );
  const [apiResponse, setApiResponse] = useState<string | null>(null);
  const [responseStatus, setResponseStatus] = useState<string | null>(null);
  const [responseLatency, setResponseLatency] = useState<number | null>(null);

  // Active Code snippet tab
  const [codeTab, setCodeTab] = useState<'js' | 'python' | 'curl' | 'react'>('js');

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKeyId(id);
    setTimeout(() => setCopiedKeyId(null), 1500);
  };

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newKeyName.trim()) return;

    const prefix = newKeyRole === 'admin' ? 'vectra_admin_' : 'vectra_search_';
    const rand = Math.random().toString(36).substring(2, 14) + Math.random().toString(36).substring(2, 8);
    const newKey: ApiKeyItem = {
      id: 'key_' + Math.random().toString(36).substring(2, 7),
      name: newKeyName.trim(),
      key: prefix + rand,
      role: newKeyRole,
      indexScope: newKeyRole === 'scoped' ? newKeyScope : undefined,
      rateLimit: newKeyRateLimit,
      createdAt: new Date().toISOString(),
      lastUsedAt: 'Never',
    };

    onCreateKey(newKey);
    setShowCreateModal(false);
    setNewKeyName('');
  };

  // Run live query through the in-memory engine
  const handleExecuteConsoleRequest = () => {
    const t0 = performance.now();
    try {
      if (requestMethod === 'POST') {
        const payload = JSON.parse(requestBody);
        const res = engine.search({
          query: payload.query || '',
          mode: payload.mode || 'hybrid',
          alpha: payload.alpha,
          filters: payload.filters || {},
          perPage: payload.perPage || 5,
        });

        const elapsed = performance.now() - t0;
        setResponseStatus('200 OK');
        setResponseLatency(Number(elapsed.toFixed(1)));
        setApiResponse(
          JSON.stringify(
            {
              status: 'success',
              took_ms: res.processingTimeMs,
              totalHits: res.totalHits,
              page: res.page,
              hits: res.hits.map((h) => ({
                id: h.id,
                score: h.score,
                breakdown: h.breakdown,
                document: h.document,
              })),
            },
            null,
            2
          )
        );
      } else {
        const elapsed = performance.now() - t0;
        setResponseStatus('200 OK');
        setResponseLatency(Number(elapsed.toFixed(1)));
        setApiResponse(
          JSON.stringify(
            {
              index: schema.id,
              primaryKey: schema.primaryKey,
              documentCount: engine.getDocuments().length,
              vectorDimension: schema.vectorDimension,
              status: 'healthy',
            },
            null,
            2
          )
        );
      }
    } catch (err: any) {
      setResponseStatus('400 Bad Request');
      setResponseLatency(0.5);
      setApiResponse(
        JSON.stringify({ error: err.message || 'JSON Parse error in payload' }, null, 2)
      );
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-neutral-800">
        <div>
          <h2 className="text-lg font-bold text-neutral-100 flex items-center gap-2">
            <Key className="w-5 h-5 text-cyan-400" />
            API Keys &amp; Developer Integration
          </h2>
          <p className="text-xs text-neutral-400 mt-0.5">
            Manage scoped client tokens, test live HTTP queries in the browser console, and integrate via InstantSearch SDKs.
          </p>
        </div>

        <button
          onClick={() => setShowCreateModal(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs bg-cyan-600 hover:bg-cyan-500 text-white rounded-md font-medium transition-colors"
        >
          <Plus className="w-3.5 h-3.5" />
          Generate New API Key
        </button>
      </div>

      {/* API Keys Table */}
      <div className="bg-neutral-900/60 border border-neutral-800 rounded-xl p-5 space-y-4 text-xs">
        <h3 className="font-semibold text-neutral-200 uppercase font-mono tracking-wider text-[11px]">
          Configured Access Credentials
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-neutral-800 text-[11px] font-mono text-neutral-400">
                <th className="py-2.5 px-3">Name</th>
                <th className="py-2.5 px-3">Role / Permissions</th>
                <th className="py-2.5 px-3">Token</th>
                <th className="py-2.5 px-3">Scope / Rate Limit</th>
                <th className="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800/60 font-sans">
              {apiKeys.map((item) => (
                <tr key={item.id} className="hover:bg-neutral-850/40 transition-colors">
                  <td className="py-2.5 px-3 font-medium text-neutral-200">
                    {item.name}
                  </td>

                  <td className="py-2.5 px-3 whitespace-nowrap">
                    <span
                      className={`font-mono text-[10px] px-2 py-0.5 rounded uppercase font-semibold ${
                        item.role === 'admin'
                          ? 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                          : 'bg-cyan-500/10 text-cyan-300 border border-cyan-500/30'
                      }`}
                    >
                      {item.role.replace('_', ' ')}
                    </span>
                  </td>

                  <td className="py-2.5 px-3 font-mono text-[11px] text-neutral-400 max-w-xs truncate">
                    <code>{item.key}</code>
                  </td>

                  <td className="py-2.5 px-3 font-mono text-[11px] text-neutral-400">
                    {item.indexScope ? `Index: ${item.indexScope}` : 'All Indexes'} · {item.rateLimit} req/s
                  </td>

                  <td className="py-2.5 px-3 text-right whitespace-nowrap">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => handleCopy(item.id, item.key)}
                        className="px-2 py-1 text-[11px] bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 rounded flex items-center gap-1 transition-colors"
                        title="Copy Key to Clipboard"
                      >
                        {copiedKeyId === item.id ? (
                          <>
                            <Check className="w-3 h-3 text-emerald-400" />
                            <span className="text-emerald-400">Copied</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3" />
                            <span>Copy</span>
                          </>
                        )}
                      </button>

                      {item.role !== 'admin' && (
                        <button
                          onClick={() => onRevokeKey(item.id)}
                          className="p-1 text-neutral-500 hover:text-rose-400 transition-colors"
                          title="Revoke Key"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Interactive REST API & cURL Console */}
      <div className="bg-neutral-900/60 border border-neutral-800 rounded-xl p-5 space-y-4 text-xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Terminal className="w-4 h-4 text-cyan-400" />
            <h3 className="font-semibold text-neutral-200">
              Interactive HTTP REST API Tester
            </h3>
          </div>
          <span className="font-mono text-[11px] text-neutral-500">
            Base URL: https://api.vectrasearch.io
          </span>
        </div>

        {/* Endpoint Bar */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
          <select
            value={requestMethod}
            onChange={(e) => setRequestMethod(e.target.value as any)}
            className="bg-neutral-950 border border-neutral-800 rounded px-3 py-2 font-mono text-cyan-400 font-bold focus:outline-none"
          >
            <option value="POST">POST</option>
            <option value="GET">GET</option>
          </select>

          <input
            type="text"
            value={requestEndpoint}
            onChange={(e) => setRequestEndpoint(e.target.value)}
            className="flex-1 bg-neutral-950 border border-neutral-800 rounded px-3 py-2 font-mono text-neutral-200 focus:outline-none"
          />

          <button
            onClick={handleExecuteConsoleRequest}
            className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded font-medium flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap"
          >
            <Play className="w-3.5 h-3.5 fill-white" />
            Send Request
          </button>
        </div>

        {/* Request / Response Split Editor */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
          <div>
            <div className="text-[11px] font-mono text-neutral-400 mb-1.5 flex items-center justify-between">
              <span>JSON Payload</span>
              <span className="text-neutral-500">application/json</span>
            </div>
            <textarea
              value={requestBody}
              onChange={(e) => setRequestBody(e.target.value)}
              rows={9}
              className="w-full bg-neutral-950 border border-neutral-800 rounded-lg p-3 font-mono text-[11px] text-neutral-200 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div>
            <div className="text-[11px] font-mono text-neutral-400 mb-1.5 flex items-center justify-between">
              <span>Response Inspector</span>
              {responseStatus && (
                <div className="flex items-center gap-2">
                  <span className="font-mono text-emerald-400 font-semibold">{responseStatus}</span>
                  <span className="text-neutral-500 font-mono">({responseLatency} ms)</span>
                </div>
              )}
            </div>
            <pre className="w-full h-[182px] bg-neutral-950 border border-neutral-800 rounded-lg p-3 font-mono text-[10px] text-cyan-200 overflow-y-auto">
              {apiResponse || '// Click "Send Request" to test against index'}
            </pre>
          </div>
        </div>
      </div>

      {/* InstantSearch SDK Code Integration */}
      <div className="bg-neutral-900/60 border border-neutral-800 rounded-xl p-5 space-y-4 text-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Code2 className="w-4 h-4 text-cyan-400" />
            <h3 className="font-semibold text-neutral-200">
              Production Client Integration Snippets
            </h3>
          </div>

          <div className="flex items-center p-0.5 bg-neutral-950 border border-neutral-800 rounded-lg font-mono text-[11px]">
            <button
              onClick={() => setCodeTab('js')}
              className={`px-3 py-1 rounded ${
                codeTab === 'js' ? 'bg-neutral-800 text-cyan-300 font-semibold' : 'text-neutral-400'
              }`}
            >
              TypeScript / JS
            </button>
            <button
              onClick={() => setCodeTab('python')}
              className={`px-3 py-1 rounded ${
                codeTab === 'python' ? 'bg-neutral-800 text-cyan-300 font-semibold' : 'text-neutral-400'
              }`}
            >
              Python
            </button>
            <button
              onClick={() => setCodeTab('curl')}
              className={`px-3 py-1 rounded ${
                codeTab === 'curl' ? 'bg-neutral-800 text-cyan-300 font-semibold' : 'text-neutral-400'
              }`}
            >
              cURL
            </button>
            <button
              onClick={() => setCodeTab('react')}
              className={`px-3 py-1 rounded ${
                codeTab === 'react' ? 'bg-neutral-800 text-cyan-300 font-semibold' : 'text-neutral-400'
              }`}
            >
              React InstantSearch
            </button>
          </div>
        </div>

        {/* Code Snippet Box */}
        <div className="relative">
          <button
            onClick={() => {
              let snippet = '';
              if (codeTab === 'js') snippet = jsSnippet(schema.id);
              if (codeTab === 'python') snippet = pythonSnippet(schema.id);
              if (codeTab === 'curl') snippet = curlSnippet(schema.id);
              if (codeTab === 'react') snippet = reactSnippet(schema.id);
              handleCopy('code_box', snippet);
            }}
            className="absolute top-3 right-3 px-2 py-1 bg-neutral-900 border border-neutral-800 hover:bg-neutral-800 rounded text-neutral-300 font-mono text-[10px] flex items-center gap-1"
          >
            {copiedKeyId === 'code_box' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
            {copiedKeyId === 'code_box' ? 'Copied' : 'Copy'}
          </button>

          <pre className="bg-neutral-950 border border-neutral-800 rounded-lg p-4 font-mono text-xs text-neutral-300 overflow-x-auto leading-relaxed">
            {codeTab === 'js' && jsSnippet(schema.id)}
            {codeTab === 'python' && pythonSnippet(schema.id)}
            {codeTab === 'curl' && curlSnippet(schema.id)}
            {codeTab === 'react' && reactSnippet(schema.id)}
          </pre>
        </div>
      </div>

      {/* Create Key Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-neutral-900 border border-neutral-800 rounded-xl w-full max-w-md shadow-2xl p-5 space-y-4 text-xs">
            <h3 className="text-sm font-semibold text-neutral-100 flex items-center gap-1.5">
              <Key className="w-4 h-4 text-cyan-400" />
              Generate API Access Token
            </h3>

            <form onSubmit={handleCreateSubmit} className="space-y-3">
              <div>
                <label className="text-neutral-400 font-mono text-[11px] block mb-1">Key Name:</label>
                <input
                  type="text"
                  required
                  value={newKeyName}
                  onChange={(e) => setNewKeyName(e.target.value)}
                  placeholder="e.g. Mobile iOS Client Key"
                  className="w-full bg-neutral-950 border border-neutral-800 rounded px-3 py-1.5 text-neutral-200"
                />
              </div>

              <div>
                <label className="text-neutral-400 font-mono text-[11px] block mb-1">Role / Permissions:</label>
                <select
                  value={newKeyRole}
                  onChange={(e) => setNewKeyRole(e.target.value as any)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded px-3 py-1.5 text-neutral-200"
                >
                  <option value="search_only">Search Only (Safe for Browser/Mobile)</option>
                  <option value="scoped">Scoped to Single Index</option>
                  <option value="admin">Full Admin (CRUD + Index Deletion)</option>
                </select>
              </div>

              {newKeyRole === 'scoped' && (
                <div>
                  <label className="text-neutral-400 font-mono text-[11px] block mb-1">Restricted Index:</label>
                  <input
                    type="text"
                    value={newKeyScope}
                    onChange={(e) => setNewKeyScope(e.target.value)}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded px-3 py-1.5 text-neutral-200 font-mono"
                  />
                </div>
              )}

              <div>
                <label className="text-neutral-400 font-mono text-[11px] block mb-1">
                  Rate Limit (Requests / Second):
                </label>
                <input
                  type="number"
                  min="10"
                  max="5000"
                  value={newKeyRateLimit}
                  onChange={(e) => setNewKeyRateLimit(parseInt(e.target.value) || 100)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded px-3 py-1.5 text-neutral-200 font-mono"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-3 py-1.5 bg-neutral-800 text-neutral-300 rounded hover:bg-neutral-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-cyan-600 text-white rounded font-medium hover:bg-cyan-500"
                >
                  Generate Key
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

function jsSnippet(indexId: string) {
  return `import { VectraClient } from '@vectrasearch/client';

const client = new VectraClient({
  appId: 'vs_prod_app',
  apiKey: 'vectra_search_pub_4a91c2b5e7d80f12',
});

// Perform hybrid search with BM25 + Vector Cosine
const { hits, processingTimeMs } = await client.index('${indexId}').search({
  query: 'noise cancelling headphones',
  mode: 'hybrid',
  alpha: 0.5, // 0.0=BM25, 1.0=Vector
  facets: ['brand', 'category'],
  filters: 'price <= 500',
});

console.log(\`Found \${hits.length} hits in \${processingTimeMs}ms\`);`;
}

function pythonSnippet(indexId: string) {
  return `import vectrasearch

client = vectrasearch.Client(
    app_id="vs_prod_app",
    api_key="vectra_search_pub_4a91c2b5e7d80f12"
)

# Execute hybrid search with RRF ranking
response = client.index("${indexId}").search({
    "query": "laptop core ultra",
    "mode": "hybrid",
    "alpha": 0.45,
    "per_page": 10
})

for hit in response["hits"]:
    print(f"[{hit['score']}] {hit['document']['title']}")`;
}

function curlSnippet(indexId: string) {
  return `curl -X POST "https://api.vectrasearch.io/v1/indexes/${indexId}/query" \\
  -H "Content-Type: application/json" \\
  -H "X-Vectra-API-Key: vectra_search_pub_4a91c2b5e7d80f12" \\
  -d '{
    "query": "macbook pro",
    "mode": "hybrid",
    "alpha": 0.5,
    "perPage": 5
  }'`;
}

function reactSnippet(indexId: string) {
  return `import { InstantSearch, SearchBox, Hits, Highlight } from 'react-instantsearch';
import { vectraSearchClient } from '@vectrasearch/instantsearch-adapter';

const searchClient = vectraSearchClient('vs_prod_app', 'vectra_search_pub_4a91c2b5e7d80f12');

export function ProductCatalog() {
  return (
    <InstantSearch searchClient={searchClient} indexName="${indexId}">
      <SearchBox placeholder="Search products..." />
      <Hits hitComponent={HitView} />
    </InstantSearch>
  );
}

function HitView({ hit }) {
  return (
    <article>
      <Highlight attribute="title" hit={hit} />
      <span>\${hit.price}</span>
    </article>
  );
}`;
}
