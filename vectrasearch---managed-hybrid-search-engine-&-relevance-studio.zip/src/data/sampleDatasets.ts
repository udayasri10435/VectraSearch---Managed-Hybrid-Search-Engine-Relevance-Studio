import { IndexSchema, DocumentRecord } from '../engine/types';
import { generateDenseEmbedding } from '../engine/vectorUtils';

export const INITIAL_INDEXES: IndexSchema[] = [
  {
    id: 'ecommerce_catalog',
    name: 'E-Commerce Product Catalog',
    description: 'High-frequency merchant inventory with BM25 title boosts, brand facets, stock filters, and vector recommendations.',
    primaryKey: 'id',
    vectorDimension: 64,
    distanceMetric: 'cosine',
    createdAt: '2026-03-15T08:00:00Z',
    fields: [
      { name: 'title', type: 'string', searchable: true, filterable: false, sortable: true, boost: 10 },
      { name: 'brand', type: 'string', searchable: true, filterable: true, sortable: true, boost: 6 },
      { name: 'category', type: 'string', searchable: true, filterable: true, sortable: true, boost: 5 },
      { name: 'description', type: 'string', searchable: true, filterable: false, sortable: false, boost: 2 },
      { name: 'tags', type: 'array', searchable: true, filterable: true, sortable: false, boost: 4 },
      { name: 'price', type: 'number', searchable: false, filterable: true, sortable: true, boost: 1 },
      { name: 'rating', type: 'number', searchable: false, filterable: true, sortable: true, boost: 1 },
      { name: 'stock', type: 'number', searchable: false, filterable: true, sortable: true, boost: 1 },
      { name: 'sales_count', type: 'number', searchable: false, filterable: false, sortable: true, boost: 1 },
      { name: '_vector', type: 'vector', searchable: true, filterable: false, sortable: false, boost: 1 },
    ],
    relevance: {
      searchableAttributes: [
        { field: 'title', weight: 10 },
        { field: 'brand', weight: 6 },
        { field: 'category', weight: 5 },
        { field: 'tags', weight: 4 },
        { field: 'description', weight: 2 },
      ],
      customRanking: [
        { field: 'sales_count', order: 'desc' },
        { field: 'rating', order: 'desc' },
        { field: 'price', order: 'asc' },
      ],
      typoTolerance: {
        enabled: true,
        minWordSizeForOneTypo: 4,
        minWordSizeForTwoTypos: 8,
        disableOnFields: ['sku', 'id'],
      },
      synonyms: [
        { id: 'syn-1', type: 'two-way', terms: ['phone', 'mobile', 'smartphone', 'cell'] },
        { id: 'syn-2', type: 'two-way', terms: ['laptop', 'notebook', 'macbook', 'pc'] },
        { id: 'syn-3', type: 'two-way', terms: ['earbuds', 'headphones', 'airpods', 'headset', 'audio'] },
        { id: 'syn-4', type: 'one-way', rootTerm: 'display', terms: ['monitor', 'screen', 'panel', 'oled'] },
      ],
      rules: [
        {
          id: 'rule-iphone-pin',
          name: 'Merchandise iPhone 16 Pro on "iphone" query',
          enabled: true,
          condition: { type: 'query_exact', value: 'iphone' },
          action: { pinDocId: 'prod_1', pinPosition: 1, boostCategory: 'Smartphones' },
        },
        {
          id: 'rule-macbook-boost',
          name: 'Prioritize Apple brand on "laptop" search',
          enabled: true,
          condition: { type: 'query_contains', value: 'laptop' },
          action: { boostCategory: 'Laptops' },
        }
      ],
      hybridConfig: {
        mode: 'hybrid',
        alpha: 0.45,
        rrfK: 60,
      },
      prefixSearch: 'last_word',
    },
  },
  {
    id: 'developer_docs',
    name: 'Developer API & Architecture Docs',
    description: 'Technical knowledge base with hybrid sparse-dense code search, tokenized API endpoints, and code guides.',
    primaryKey: 'id',
    vectorDimension: 64,
    distanceMetric: 'cosine',
    createdAt: '2026-03-18T10:30:00Z',
    fields: [
      { name: 'title', type: 'string', searchable: true, filterable: false, sortable: true, boost: 10 },
      { name: 'endpoint', type: 'string', searchable: true, filterable: true, sortable: true, boost: 8 },
      { name: 'section', type: 'string', searchable: true, filterable: true, sortable: true, boost: 6 },
      { name: 'summary', type: 'string', searchable: true, filterable: false, sortable: false, boost: 4 },
      { name: 'codeSnippet', type: 'string', searchable: true, filterable: false, sortable: false, boost: 3 },
      { name: 'tags', type: 'array', searchable: true, filterable: true, sortable: false, boost: 5 },
      { name: 'difficulty', type: 'string', searchable: false, filterable: true, sortable: true, boost: 1 },
      { name: 'views', type: 'number', searchable: false, filterable: false, sortable: true, boost: 1 },
      { name: '_vector', type: 'vector', searchable: true, filterable: false, sortable: false, boost: 1 },
    ],
    relevance: {
      searchableAttributes: [
        { field: 'title', weight: 10 },
        { field: 'endpoint', weight: 8 },
        { field: 'section', weight: 6 },
        { field: 'tags', weight: 5 },
        { field: 'summary', weight: 4 },
        { field: 'codeSnippet', weight: 3 },
      ],
      customRanking: [
        { field: 'views', order: 'desc' },
      ],
      typoTolerance: {
        enabled: true,
        minWordSizeForOneTypo: 5,
        minWordSizeForTwoTypos: 9,
        disableOnFields: ['endpoint'],
      },
      synonyms: [
        { id: 'syn-doc-1', type: 'two-way', terms: ['auth', 'authentication', 'api-key', 'bearer', 'token'] },
        { id: 'syn-doc-2', type: 'two-way', terms: ['vector', 'embeddings', 'dense', 'semantic'] },
        { id: 'syn-doc-3', type: 'two-way', terms: ['bulk', 'batch', 'ingest', 'import'] },
      ],
      rules: [
        {
          id: 'rule-quickstart-pin',
          name: 'Pin Quickstart on Getting Started',
          enabled: true,
          condition: { type: 'query_contains', value: 'quickstart' },
          action: { pinDocId: 'doc_1', pinPosition: 1 },
        }
      ],
      hybridConfig: {
        mode: 'hybrid',
        alpha: 0.6,
        rrfK: 60,
      },
      prefixSearch: 'all',
    },
  },
  {
    id: 'media_entertainment',
    name: 'Cinematic Films & Streaming Media',
    description: 'Entertainment catalog supporting natural language vector queries ("mind-bending space journey") and genre filtering.',
    primaryKey: 'id',
    vectorDimension: 64,
    distanceMetric: 'cosine',
    createdAt: '2026-03-20T14:15:00Z',
    fields: [
      { name: 'title', type: 'string', searchable: true, filterable: false, sortable: true, boost: 10 },
      { name: 'director', type: 'string', searchable: true, filterable: true, sortable: true, boost: 7 },
      { name: 'genres', type: 'array', searchable: true, filterable: true, sortable: false, boost: 6 },
      { name: 'synopsis', type: 'string', searchable: true, filterable: false, sortable: false, boost: 4 },
      { name: 'cast', type: 'array', searchable: true, filterable: true, sortable: false, boost: 5 },
      { name: 'year', type: 'number', searchable: false, filterable: true, sortable: true, boost: 1 },
      { name: 'rating', type: 'number', searchable: false, filterable: true, sortable: true, boost: 1 },
      { name: 'votes', type: 'number', searchable: false, filterable: false, sortable: true, boost: 1 },
      { name: '_vector', type: 'vector', searchable: true, filterable: false, sortable: false, boost: 1 },
    ],
    relevance: {
      searchableAttributes: [
        { field: 'title', weight: 10 },
        { field: 'director', weight: 7 },
        { field: 'genres', weight: 6 },
        { field: 'cast', weight: 5 },
        { field: 'synopsis', weight: 4 },
      ],
      customRanking: [
        { field: 'rating', order: 'desc' },
        { field: 'votes', order: 'desc' },
        { field: 'year', order: 'desc' },
      ],
      typoTolerance: {
        enabled: true,
        minWordSizeForOneTypo: 4,
        minWordSizeForTwoTypos: 8,
        disableOnFields: [],
      },
      synonyms: [
        { id: 'syn-m-1', type: 'two-way', terms: ['scifi', 'sci-fi', 'science fiction', 'space', 'futuristic'] },
        { id: 'syn-m-2', type: 'two-way', terms: ['thriller', 'suspense', 'mystery'] },
      ],
      rules: [],
      hybridConfig: {
        mode: 'hybrid',
        alpha: 0.65,
        rrfK: 60,
      },
      prefixSearch: 'last_word',
    },
  },
];

export type RawDoc = { id: string; [key: string]: any };

const RAW_ECOMMERCE_DOCS: RawDoc[] = [
  {
    id: 'prod_1',
    title: 'Apple iPhone 16 Pro Max 256GB Titanium',
    brand: 'Apple',
    category: 'Smartphones',
    price: 1199,
    rating: 4.9,
    stock: 42,
    sales_count: 14820,
    tags: ['5G', 'A18 Pro', 'Titanium', '48MP Camera', 'iOS 18', 'Action Button'],
    description: 'Flagship smartphone featuring Grade 5 titanium design, 6.9-inch Super Retina XDR OLED display, A18 Pro chip with 6-core GPU, and Camera Control button.',
  },
  {
    id: 'prod_2',
    title: 'Samsung Galaxy S25 Ultra 512GB Titanium Black',
    brand: 'Samsung',
    category: 'Smartphones',
    price: 1299,
    rating: 4.8,
    stock: 28,
    sales_count: 11200,
    tags: ['Galaxy AI', 'Snapdragon 8 Elite', '200MP Camera', 'S-Pen', 'AMOLED 2X'],
    description: 'Premium Android smartphone built with titanium frame, integrated S-Pen stylus, Quad Telephoto camera system with 100x Space Zoom, and Galaxy AI.',
  },
  {
    id: 'prod_3',
    title: 'Apple MacBook Pro 16-inch M4 Max 36GB / 1TB',
    brand: 'Apple',
    category: 'Laptops',
    price: 3499,
    rating: 4.95,
    stock: 15,
    sales_count: 5340,
    tags: ['M4 Max', 'Liquid Retina XDR', 'Thunderbolt 5', 'ProRes', 'macOS Sequoia'],
    description: 'The ultimate pro laptop powered by Apple M4 Max with 14-core CPU and 32-core GPU, 24-hour battery life, 16.2-inch Liquid Retina XDR screen with nano-texture glass.',
  },
  {
    id: 'prod_4',
    title: 'Dell XPS 16 Laptop Intel Core Ultra 9 RTX 4070',
    brand: 'Dell',
    category: 'Laptops',
    price: 2699,
    rating: 4.6,
    stock: 19,
    sales_count: 3120,
    tags: ['Intel Core Ultra 9', 'GeForce RTX 4070', '4K OLED', 'CNC Aluminum', 'Windows 11 Pro'],
    description: 'Sleek CNC machined aluminum powerhouse laptop with seamless glass touchpad, capacitive touch function keys, and 16.3-inch 4K+ InfinityEdge OLED display.',
  },
  {
    id: 'prod_5',
    title: 'Sony WH-1000XM5 Wireless Noise-Canceling Headphones',
    brand: 'Sony',
    category: 'Audio',
    price: 399,
    rating: 4.85,
    stock: 64,
    sales_count: 18900,
    tags: ['ANC', 'Hi-Res Audio', 'LDAC', '30hr Battery', 'Multipoint Bluetooth'],
    description: 'Industry-leading noise canceling over-ear headphones with two processors and eight microphones, Auto NC Optimizer, and crystal-clear hands-free calling.',
  },
  {
    id: 'prod_6',
    title: 'Bose QuietComfort Ultra Wireless Earbuds',
    brand: 'Bose',
    category: 'Audio',
    price: 299,
    rating: 4.7,
    stock: 53,
    sales_count: 14100,
    tags: ['Spatial Audio', 'CustomTune', 'Active Noise Canceling', 'IPX4', 'Earbuds'],
    description: 'Breakthrough spatialized audio earbuds with world-class noise cancellation tailored to ear shape, CustomTune technology, and all-day comfort ear tips.',
  },
  {
    id: 'prod_7',
    title: 'Fujifilm X-T5 Mirrorless Camera with 16-80mm Lens',
    brand: 'Fujifilm',
    category: 'Cameras',
    price: 2199,
    rating: 4.9,
    stock: 11,
    sales_count: 2450,
    tags: ['40.2MP', 'X-Trans CMOS 5 HR', '6.2K Video', '7-stop IBIS', 'Film Simulation'],
    description: 'Classic dial-based mirrorless camera featuring 40.2 megapixel back-illuminated X-Trans 5 sensor, 5-axis in-body image stabilization, and legendary color science.',
  },
  {
    id: 'prod_8',
    title: 'Canon EOS R6 Mark II Full-Frame Mirrorless Body',
    brand: 'Canon',
    category: 'Cameras',
    price: 2299,
    rating: 4.88,
    stock: 8,
    sales_count: 3890,
    tags: ['24.2MP Full-Frame', '40 fps Burst', 'Dual Pixel CMOS AF II', '4K 60p'],
    description: 'High-speed full-frame hybrid camera capable of up to 40 frames per second continuous electronic shooting, advanced subject tracking AI, and 6K oversampled video.',
  },
  {
    id: 'prod_9',
    title: 'LG OLED G4 65-inch 4K Smart TV with Alpha 11 AI',
    brand: 'LG',
    category: 'Smart Home',
    price: 2799,
    rating: 4.92,
    stock: 14,
    sales_count: 4210,
    tags: ['OLED', '144Hz', 'G-Sync', 'Brightness Booster Max', 'webOS 24', 'Dolby Vision'],
    description: 'Gallery design 65-inch OLED TV with self-lit pixels, Brightness Booster Max micro-lens array, Alpha 11 AI processor 4K, and 4 HDMI 2.1 ports for low latency gaming.',
  },
  {
    id: 'prod_10',
    title: 'Keychron Q1 Pro Wireless QMK Custom Mechanical Keyboard',
    brand: 'Keychron',
    category: 'Accessories',
    price: 199,
    rating: 4.8,
    stock: 77,
    sales_count: 9800,
    tags: ['Mechanical', 'Gasket Mount', 'Hot-Swappable', 'CNC Aluminum', 'Bluetooth 5.1'],
    description: 'Fully customizable 75% layout mechanical keyboard with full CNC aluminum body, double-gasket design, screw-in stabilizers, and wireless multi-device pairing.',
  },
  {
    id: 'prod_11',
    title: 'Logitech MX Master 3S Performance Wireless Mouse',
    brand: 'Logitech',
    category: 'Accessories',
    price: 99,
    rating: 4.87,
    stock: 120,
    sales_count: 34500,
    tags: ['8K DPI Track-on-Glass', 'Quiet Clicks', 'MagSpeed Scroll', 'Ergonomic'],
    description: 'Ergonomic wireless mouse with 8,000 DPI optical sensor that works on glass, electromagnetic MagSpeed wheel scrolling 1,000 lines per second, and quiet switch buttons.',
  },
  {
    id: 'prod_12',
    title: 'Apple iPad Pro 13-inch M4 Ultra Retina Tandem OLED',
    brand: 'Apple',
    category: 'Tablets',
    price: 1299,
    rating: 4.93,
    stock: 31,
    sales_count: 12400,
    tags: ['M4 Chip', 'Tandem OLED', 'ProMotion 120Hz', 'Apple Pencil Pro', 'Thunderbolt'],
    description: 'Impossibly thin 5.1mm tablet featuring groundbreaking Tandem OLED Ultra Retina display, next-gen M4 silicon, and Apple Pencil Pro barrel roll and haptic feedback support.',
  },
  {
    id: 'prod_13',
    title: 'Google Pixel 9 Pro Fold 256GB Obsidian',
    brand: 'Google',
    category: 'Smartphones',
    price: 1799,
    rating: 4.65,
    stock: 16,
    sales_count: 2900,
    tags: ['Tensor G4', 'Foldable', 'Gemini Nano', 'Super Actua Display', 'IPX8'],
    description: 'Foldable phone with 8-inch Super Actua Flex inner display, Google Tensor G4 with 16GB RAM for on-device Gemini AI, triple rear camera, and split-screen multitasking.',
  },
  {
    id: 'prod_14',
    title: 'Sonos Era 300 Spatial Audio Smart Speaker',
    brand: 'Sonos',
    category: 'Audio',
    price: 449,
    rating: 4.75,
    stock: 38,
    sales_count: 6700,
    tags: ['Dolby Atmos', 'Spatial Audio', 'AirPlay 2', 'Trueplay Tuning', 'WiFi 6'],
    description: 'Revolutionary acoustic architecture with six optimally positioned drivers all around the front, sides, and top to project sound wall-to-wall with Dolby Atmos music.',
  },
  {
    id: 'prod_15',
    title: 'Herman Miller Embody Ergonomic Office Chair',
    brand: 'Herman Miller',
    category: 'Furniture',
    price: 1745,
    rating: 4.94,
    stock: 9,
    sales_count: 4500,
    tags: ['Ergonomic', 'Pixelated Support', 'Spine Alignment', 'Breathable', 'Made in USA'],
    description: 'Engineered with physician input to enhance oxygen flow and reduce sitting fatigue, featuring dynamic matrix of pixels that conforms to micro-movements of your spine.',
  },
  {
    id: 'prod_16',
    title: 'DJI Mini 4 Pro Drone Fly More Combo Plus with RC 2',
    brand: 'DJI',
    category: 'Cameras',
    price: 1099,
    rating: 4.91,
    stock: 22,
    sales_count: 8100,
    tags: ['Under 249g', '4K 60p HDR True Vertical', 'Omnidirectional Obstacle Sensing', 'O4 Video'],
    description: 'Sub-249g ultra-portable camera drone with omnidirectional active obstacle sensing, 4K/60fps HDR true vertical shooting for social media, and up to 45 minutes flight time.',
  }
];

const RAW_DEVELOPER_DOCS: RawDoc[] = [
  {
    id: 'doc_1',
    title: 'Getting Started: Fast Ingestion & Index Creation',
    endpoint: 'POST /v1/indexes',
    section: 'Guides',
    difficulty: 'Beginner',
    views: 18450,
    tags: ['quickstart', 'indexing', 'setup', 'curl'],
    summary: 'Define index schemas, declare searchable vs filterable attributes, specify vector embedding dimensions, and provision in seconds.',
    codeSnippet: `const index = await client.createIndex({
  id: "products",
  fields: [
    { name: "title", type: "string", searchable: true },
    { name: "embedding", type: "vector", dimension: 768 }
  ]
});`,
  },
  {
    id: 'doc_2',
    title: 'Hybrid Search: Combining BM25 with Dense Vectors (RRF)',
    endpoint: 'POST /v1/indexes/:id/query',
    section: 'Search Engine',
    difficulty: 'Advanced',
    views: 24100,
    tags: ['hybrid', 'rrf', 'bm25', 'vector', 'cosine', 'relevance'],
    summary: 'Balance exact keyword precision with conceptual semantic understanding using Reciprocal Rank Fusion and alpha tuning parameters.',
    codeSnippet: `const results = await index.search({
  query: "lightweight travel laptop",
  mode: "hybrid",
  alpha: 0.5, // 0.0=pure BM25, 1.0=pure vector
  rrfK: 60
});`,
  },
  {
    id: 'doc_3',
    title: 'Configuring Typo Tolerance & Levenshtein Distances',
    endpoint: 'PUT /v1/indexes/:id/settings/typo-tolerance',
    section: 'Relevance Tuning',
    difficulty: 'Intermediate',
    views: 14200,
    tags: ['typos', 'fuzzy', 'levenshtein', 'relevance'],
    summary: 'Configure minimum query word lengths for 1 or 2 typos, exclude SKUs, and prevent false positive matching on short abbreviations.',
    codeSnippet: `await index.updateTypoTolerance({
  enabled: true,
  minWordSizeForOneTypo: 4,
  minWordSizeForTwoTypos: 8,
  disableOnFields: ["sku", "model_number"]
});`,
  },
  {
    id: 'doc_4',
    title: 'Synonym Dictionaries & Query Expansion Rules',
    endpoint: 'POST /v1/indexes/:id/synonyms',
    section: 'Relevance Tuning',
    difficulty: 'Intermediate',
    views: 11900,
    tags: ['synonyms', 'merchandising', 'aliases', 'queries'],
    summary: 'Map colloquial customer search terms (e.g., kicks -> sneakers) bidirectionally or define one-way domain aliases.',
    codeSnippet: `await index.addSynonymRule({
  type: "two-way",
  terms: ["sneakers", "trainers", "kicks", "shoes"]
});`,
  },
  {
    id: 'doc_5',
    title: 'Scoped API Keys & Role-Based Permissions',
    endpoint: 'POST /v1/keys',
    section: 'Security & Auth',
    difficulty: 'Beginner',
    views: 9800,
    tags: ['auth', 'api-key', 'security', 'rbac', 'rate-limit'],
    summary: 'Create search-only frontend keys, limit queries to specific indexes, embed user filters (tenant isolation), and rate-limit clients.',
    codeSnippet: `const searchKey = await client.createKey({
  role: "search_only",
  indexes: ["public_catalog"],
  rateLimitPerSec: 100,
  maxLifetimeDays: 90
});`,
  },
  {
    id: 'doc_6',
    title: 'Custom Ranking & Merchandising Rules',
    endpoint: 'PUT /v1/indexes/:id/settings/ranking',
    section: 'Relevance Tuning',
    difficulty: 'Advanced',
    views: 16700,
    tags: ['ranking', 'merchandising', 'boosting', 'rules'],
    summary: 'Combine textual relevance score with business signals (sales, rating, margin, stock level) and manually pin promotional hero items.',
    codeSnippet: `await index.updateCustomRanking([
  { field: "sales_count", order: "desc" },
  { field: "rating", order: "desc" },
  { field: "price", order: "asc" }
]);`,
  },
  {
    id: 'doc_7',
    title: 'Faceting & Numerical Filter Grammar',
    endpoint: 'POST /v1/indexes/:id/query#facets',
    section: 'Search Engine',
    difficulty: 'Intermediate',
    views: 13500,
    tags: ['facets', 'filters', 'boolean', 'ranges', 'counts'],
    summary: 'Compute instant facet distributions for categories, brands, price buckets, and apply complex boolean filter expressions.',
    codeSnippet: `const res = await index.search({
  query: "headphones",
  facets: ["brand", "category", "in_stock"],
  filters: "price >= 100 AND price <= 500 AND rating > 4.5"
});`,
  },
  {
    id: 'doc_8',
    title: 'Real-Time Analytics & Zero-Hit Query Telemetry',
    endpoint: 'GET /v1/indexes/:id/analytics',
    section: 'Analytics',
    difficulty: 'Beginner',
    views: 15100,
    tags: ['analytics', 'ctr', 'zero-hit', 'telemetry', 'monitoring'],
    summary: 'Track search click-through rates, p95 query latency, and identify unserved user intent with zero-result search logs.',
    codeSnippet: `const analytics = await index.getAnalytics({
  timeframe: "7d",
  metrics: ["total_searches", "zero_hit_rate", "avg_latency_ms"]
});`,
  }
];

const RAW_MEDIA_DOCS: RawDoc[] = [
  {
    id: 'media_1',
    title: 'Interstellar',
    director: 'Christopher Nolan',
    genres: ['Sci-Fi', 'Drama', 'Adventure'],
    year: 2014,
    rating: 8.7,
    votes: 2150000,
    cast: ['Matthew McConaughey', 'Anne Hathaway', 'Jessica Chastain', 'Michael Caine'],
    synopsis: 'When Earth becomes uninhabitable in the future, a farmer and ex-NASA pilot, Joseph Cooper, is tasked to pilot a spacecraft along with a team of researchers through a wormhole to find a new planet for humans.',
  },
  {
    id: 'media_2',
    title: 'Blade Runner 2049',
    director: 'Denis Villeneuve',
    genres: ['Sci-Fi', 'Mystery', 'Drama'],
    year: 2017,
    rating: 8.0,
    votes: 680000,
    cast: ['Ryan Gosling', 'Harrison Ford', 'Ana de Armas', 'Sylvia Hoeks'],
    synopsis: 'Young Blade Runner K unearths a long-buried secret that has the potential to plunge what is left of society into chaos, leading him on a quest to find former runner Rick Deckard.',
  },
  {
    id: 'media_3',
    title: 'Inception',
    director: 'Christopher Nolan',
    genres: ['Sci-Fi', 'Action', 'Adventure'],
    year: 2010,
    rating: 8.8,
    votes: 2600000,
    cast: ['Leonardo DiCaprio', 'Joseph Gordon-Levitt', 'Elliot Page', 'Tom Hardy'],
    synopsis: 'A thief who steals corporate secrets through the use of dream-sharing technology is given the inverse task of planting an idea into the mind of a C.E.O., but his tragic past may doom the project.',
  },
  {
    id: 'media_4',
    title: 'Dune: Part Two',
    director: 'Denis Villeneuve',
    genres: ['Sci-Fi', 'Adventure', 'Action'],
    year: 2024,
    rating: 8.6,
    votes: 560000,
    cast: ['Timothée Chalamet', 'Zendaya', 'Rebecca Ferguson', 'Javier Bardem'],
    synopsis: 'Paul Atreides unites with Chani and the Fremen while seeking revenge against the conspirators who destroyed his family, facing a choice between the love of his life and the fate of the universe.',
  },
  {
    id: 'media_5',
    title: 'The Dark Knight',
    director: 'Christopher Nolan',
    genres: ['Action', 'Crime', 'Drama'],
    year: 2008,
    rating: 9.0,
    votes: 2950000,
    cast: ['Christian Bale', 'Heath Ledger', 'Aaron Eckhart', 'Gary Oldman'],
    synopsis: 'When the menace known as the Joker wreaks havoc and chaos on the people of Gotham, Batman must accept one of the greatest psychological and physical tests of his ability to fight injustice.',
  },
  {
    id: 'media_6',
    title: 'Arrival',
    director: 'Denis Villeneuve',
    genres: ['Sci-Fi', 'Mystery', 'Drama'],
    year: 2016,
    rating: 7.9,
    votes: 750000,
    cast: ['Amy Adams', 'Jeremy Renner', 'Forest Whitaker', 'Michael Stuhlbarg'],
    synopsis: 'Linguistics professor Louise Banks leads an elite team of investigators when gigantic spaceships touch down in 12 locations around the world, racing against time to decipher alien communications.',
  },
  {
    id: 'media_7',
    title: 'Parasite',
    director: 'Bong Joon Ho',
    genres: ['Drama', 'Thriller'],
    year: 2019,
    rating: 8.5,
    votes: 980000,
    cast: ['Song Kang-ho', 'Lee Sun-kyun', 'Cho Yeo-jeong', 'Choi Woo-shik'],
    synopsis: 'Greed and class discrimination threaten the newly formed symbiotic relationship between the wealthy Park family and the destitute Kim clan.',
  },
  {
    id: 'media_8',
    title: 'Oppenheimer',
    director: 'Christopher Nolan',
    genres: ['Biography', 'Drama', 'History'],
    year: 2023,
    rating: 8.9,
    votes: 820000,
    cast: ['Cillian Murphy', 'Emily Blunt', 'Matt Damon', 'Robert Downey Jr.'],
    synopsis: 'The story of American scientist J. Robert Oppenheimer and his role in the development of the atomic bomb during the Manhattan Project.',
  }
];

export function buildInitialDocuments(indexId: string): DocumentRecord[] {
  let raw: RawDoc[] = [];
  if (indexId === 'ecommerce_catalog') {
    raw = RAW_ECOMMERCE_DOCS;
  } else if (indexId === 'developer_docs') {
    raw = RAW_DEVELOPER_DOCS;
  } else if (indexId === 'media_entertainment') {
    raw = RAW_MEDIA_DOCS;
  }

  return raw.map((item): DocumentRecord => {
    // Generate semantic embedding vector from text fields
    const textBlob = Object.entries(item)
      .filter(([k]) => k !== 'id')
      .map(([_, v]) => (Array.isArray(v) ? v.join(' ') : String(v)))
      .join(' ');

    const vector = generateDenseEmbedding(textBlob, 64);
    const { id, ...rest } = item;
    return {
      id,
      ...rest,
      _vector: vector,
    };
  });
}

export const INITIAL_API_KEYS = [
  {
    id: 'key_admin_live',
    name: 'Production Master Admin Key',
    key: 'vectra_admin_live_8f3d1e90a42bc579d1a8e',
    role: 'admin' as const,
    rateLimit: 1000,
    createdAt: '2026-03-01T12:00:00Z',
    lastUsedAt: 'Just now',
  },
  {
    id: 'key_search_frontend',
    name: 'Client InstantSearch Public Key',
    key: 'vectra_search_pub_4a91c2b5e7d80f12',
    role: 'search_only' as const,
    indexScope: 'ecommerce_catalog',
    rateLimit: 150,
    createdAt: '2026-03-10T09:30:00Z',
    lastUsedAt: '2 mins ago',
  },
  {
    id: 'key_docs_public',
    name: 'DocSearch Widget Key',
    key: 'vectra_search_docs_9c13b7e41fa89',
    role: 'search_only' as const,
    indexScope: 'developer_docs',
    rateLimit: 200,
    createdAt: '2026-03-12T15:40:00Z',
    lastUsedAt: '12 mins ago',
  }
];
