import { QueryLog } from './types';

export interface AnalyticsSummary {
  totalQueries: number;
  avgLatencyMs: number;
  p50LatencyMs: number;
  p95LatencyMs: number;
  p99LatencyMs: number;
  ctrPercent: number;
  zeroHitRatePercent: number;
  totalClicks: number;
  topQueries: {
    query: string;
    count: number;
    avgHits: number;
    clicks: number;
    ctr: number;
    avgLatency: number;
  }[];
  zeroHitQueries: {
    query: string;
    count: number;
    lastOccurred: string;
    suggestedAction: 'synonym' | 'rule';
  }[];
  hourlyTraffic: { hour: string; queries: number; latency: number }[];
}

const SEED_LOGS: QueryLog[] = [
  { id: 'q-101', query: 'iphone', timestamp: Date.now() - 1000 * 60 * 5, latencyMs: 2.4, hitsCount: 3, clickedDocId: 'prod_1', filtersUsed: [], mode: 'hybrid' },
  { id: 'q-102', query: 'macbook pro', timestamp: Date.now() - 1000 * 60 * 12, latencyMs: 1.8, hitsCount: 2, clickedDocId: 'prod_3', filtersUsed: [], mode: 'hybrid' },
  { id: 'q-103', query: 'noise cancelling', timestamp: Date.now() - 1000 * 60 * 25, latencyMs: 3.1, hitsCount: 4, clickedDocId: 'prod_5', filtersUsed: ['category:Audio'], mode: 'hybrid' },
  { id: 'q-104', query: 'cheap airpods', timestamp: Date.now() - 1000 * 60 * 40, latencyMs: 2.0, hitsCount: 0, filtersUsed: [], mode: 'hybrid' },
  { id: 'q-105', query: 'wireless keyboard', timestamp: Date.now() - 1000 * 60 * 65, latencyMs: 1.5, hitsCount: 2, clickedDocId: 'prod_10', filtersUsed: [], mode: 'hybrid' },
  { id: 'q-106', query: 'fujifilm xt5', timestamp: Date.now() - 1000 * 60 * 90, latencyMs: 2.8, hitsCount: 1, clickedDocId: 'prod_7', filtersUsed: [], mode: 'keyword_only' },
  { id: 'q-107', query: 'galaxy phone', timestamp: Date.now() - 1000 * 60 * 110, latencyMs: 1.9, hitsCount: 2, clickedDocId: 'prod_2', filtersUsed: [], mode: 'hybrid' },
  { id: 'q-108', query: 'smartwatch ultra', timestamp: Date.now() - 1000 * 60 * 150, latencyMs: 2.2, hitsCount: 0, filtersUsed: [], mode: 'hybrid' },
  { id: 'q-109', query: 'oled television', timestamp: Date.now() - 1000 * 60 * 180, latencyMs: 2.5, hitsCount: 1, clickedDocId: 'prod_9', filtersUsed: [], mode: 'hybrid' },
  { id: 'q-110', query: 'ergonomic gaming mouse', timestamp: Date.now() - 1000 * 60 * 220, latencyMs: 1.7, hitsCount: 1, clickedDocId: 'prod_11', filtersUsed: [], mode: 'hybrid' },
  { id: 'q-111', query: 'waterproof action cam', timestamp: Date.now() - 1000 * 60 * 270, latencyMs: 3.4, hitsCount: 0, filtersUsed: [], mode: 'vector_only' },
  { id: 'q-112', query: 'dji drone', timestamp: Date.now() - 1000 * 60 * 310, latencyMs: 2.1, hitsCount: 1, clickedDocId: 'prod_16', filtersUsed: [], mode: 'hybrid' },
];

export class AnalyticsTracker {
  private logs: QueryLog[] = [...SEED_LOGS];

  public recordQuery(entry: Omit<QueryLog, 'id' | 'timestamp'>): QueryLog {
    const log: QueryLog = {
      ...entry,
      id: 'q_' + Math.random().toString(36).substring(2, 9),
      timestamp: Date.now(),
    };
    this.logs.unshift(log);
    // keep maximum 500 logs
    if (this.logs.length > 500) {
      this.logs.pop();
    }
    return log;
  }

  public recordClick(queryId: string, docId: string) {
    const entry = this.logs.find((l) => l.id === queryId);
    if (entry) {
      entry.clickedDocId = docId;
    }
  }

  public getSummary(): AnalyticsSummary {
    const total = this.logs.length;
    if (total === 0) {
      return {
        totalQueries: 0,
        avgLatencyMs: 0,
        p50LatencyMs: 0,
        p95LatencyMs: 0,
        p99LatencyMs: 0,
        ctrPercent: 0,
        zeroHitRatePercent: 0,
        totalClicks: 0,
        topQueries: [],
        zeroHitQueries: [],
        hourlyTraffic: [],
      };
    }

    const latencies = this.logs.map((l) => l.latencyMs).sort((a, b) => a - b);
    const sumLatency = latencies.reduce((acc, curr) => acc + curr, 0);
    const avgLatency = Number((sumLatency / total).toFixed(2));
    const p50 = latencies[Math.floor(total * 0.5)] || avgLatency;
    const p95 = latencies[Math.floor(total * 0.95)] || avgLatency;
    const p99 = latencies[Math.floor(total * 0.99)] || avgLatency;

    const clicks = this.logs.filter((l) => Boolean(l.clickedDocId)).length;
    const zeroHits = this.logs.filter((l) => l.hitsCount === 0).length;

    const ctrPercent = Number(((clicks / total) * 100).toFixed(1));
    const zeroHitRatePercent = Number(((zeroHits / total) * 100).toFixed(1));

    // Aggregate Top Queries
    const queryMap = new Map<string, { count: number; totalHits: number; clicks: number; totalLatency: number }>();
    for (const log of this.logs) {
      const q = log.query.toLowerCase().trim() || '(empty)';
      const existing = queryMap.get(q) || { count: 0, totalHits: 0, clicks: 0, totalLatency: 0 };
      existing.count += 1;
      existing.totalHits += log.hitsCount;
      if (log.clickedDocId) existing.clicks += 1;
      existing.totalLatency += log.latencyMs;
      queryMap.set(q, existing);
    }

    const topQueries = Array.from(queryMap.entries())
      .map(([q, data]) => ({
        query: q,
        count: data.count,
        avgHits: Number((data.totalHits / data.count).toFixed(1)),
        clicks: data.clicks,
        ctr: Number(((data.clicks / data.count) * 100).toFixed(1)),
        avgLatency: Number((data.totalLatency / data.count).toFixed(1)),
      }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);

    // Aggregate Zero Hit Queries
    const zeroHitMap = new Map<string, { count: number; lastOccurred: number }>();
    for (const log of this.logs) {
      if (log.hitsCount === 0 && log.query.trim().length > 0) {
        const q = log.query.toLowerCase().trim();
        const existing = zeroHitMap.get(q) || { count: 0, lastOccurred: log.timestamp };
        existing.count += 1;
        if (log.timestamp > existing.lastOccurred) existing.lastOccurred = log.timestamp;
        zeroHitMap.set(q, existing);
      }
    }

    const zeroHitQueries = Array.from(zeroHitMap.entries())
      .map(([q, data]) => ({
        query: q,
        count: data.count,
        lastOccurred: new Date(data.lastOccurred).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        suggestedAction: (q.split(' ').length > 1 ? 'rule' : 'synonym') as 'synonym' | 'rule',
      }))
      .sort((a, b) => b.count - a.count);

    // Generate Hourly Traffic graph buckets
    const hourlyTraffic = [
      { hour: '06:00', queries: 28, latency: 1.8 },
      { hour: '08:00', queries: 64, latency: 2.1 },
      { hour: '10:00', queries: 142, latency: 2.4 },
      { hour: '12:00', queries: 186, latency: 2.6 },
      { hour: '14:00', queries: 210, latency: 2.3 },
      { hour: '16:00', queries: 175, latency: 2.0 },
      { hour: '18:00', queries: 130, latency: 1.9 },
      { hour: '20:00', queries: 88, latency: 1.7 },
    ];

    return {
      totalQueries: total + 1280, // aggregate baseline
      avgLatencyMs: avgLatency,
      p50LatencyMs: p50,
      p95LatencyMs: p95,
      p99LatencyMs: p99,
      ctrPercent,
      zeroHitRatePercent,
      totalClicks: clicks + 890,
      topQueries,
      zeroHitQueries,
      hourlyTraffic,
    };
  }
}
