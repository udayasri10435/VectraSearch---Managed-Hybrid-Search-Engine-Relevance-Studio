import {
  DocumentRecord,
  FacetCount,
  IndexSchema,
  SearchQueryOptions,
  SearchResponse,
  SearchResultHit,
} from './types';
import {
  cosineSimilarity,
  damerauLevenshtein,
  generateDenseEmbedding,
  tokenize,
} from './vectorUtils';

export class SearchEngine {
  private schema: IndexSchema;
  private documents: DocumentRecord[];

  constructor(schema: IndexSchema, documents: DocumentRecord[]) {
    this.schema = schema;
    this.documents = documents;
  }

  public updateSchema(newSchema: IndexSchema) {
    this.schema = newSchema;
  }

  public setDocuments(docs: DocumentRecord[]) {
    this.documents = docs;
  }

  public getDocuments(): DocumentRecord[] {
    return this.documents;
  }

  public addDocument(doc: DocumentRecord) {
    // Ensure document has vector embedding
    if (!doc._vector || !Array.isArray(doc._vector)) {
      const textBlob = Object.entries(doc)
        .filter(([k]) => k !== 'id' && k !== '_vector')
        .map(([_, v]) => (Array.isArray(v) ? v.join(' ') : String(v)))
        .join(' ');
      doc._vector = generateDenseEmbedding(textBlob, this.schema.vectorDimension || 64);
    }
    this.documents.push(doc);
  }

  public updateDocument(id: string, updated: Partial<DocumentRecord>) {
    const idx = this.documents.findIndex((d) => d.id === id);
    if (idx !== -1) {
      this.documents[idx] = { ...this.documents[idx], ...updated };
      // Regenerate embedding if key fields updated
      const textBlob = Object.entries(this.documents[idx])
        .filter(([k]) => k !== 'id' && k !== '_vector')
        .map(([_, v]) => (Array.isArray(v) ? v.join(' ') : String(v)))
        .join(' ');
      this.documents[idx]._vector = generateDenseEmbedding(textBlob, this.schema.vectorDimension || 64);
    }
  }

  public deleteDocument(id: string) {
    this.documents = this.documents.filter((d) => d.id !== id);
  }

  /**
   * Execute full hybrid search with BM25, Typo Tolerance, Vector Cosine, Merchandising & Highlighting
   */
  public search(options: SearchQueryOptions): SearchResponse {
    const startTime = performance.now();
    const rawQuery = (options.query || '').trim();
    const mode = options.mode || this.schema.relevance.hybridConfig.mode || 'hybrid';
    const alpha = options.alpha !== undefined ? options.alpha : (this.schema.relevance.hybridConfig.alpha ?? 0.5);
    const page = options.page || 1;
    const perPage = options.perPage || 12;
    const filters = options.filters || {};

    // 1. Expand query terms using Synonyms dictionary
    const queryTokens = tokenize(rawQuery);
    const expandedTokens = this.expandSynonyms(queryTokens);

    // 2. Evaluate Merchandising Rules
    let activeRuleName: string | undefined;
    let pinnedDocId: string | undefined;
    let pinPosition = 1;
    let boostCategory: string | undefined;

    for (const rule of this.schema.relevance.rules || []) {
      if (!rule.enabled) continue;
      const lowerQ = rawQuery.toLowerCase();
      const val = rule.condition.value.toLowerCase();
      let matched = false;

      if (rule.condition.type === 'query_exact' && lowerQ === val) {
        matched = true;
      } else if (rule.condition.type === 'query_contains' && lowerQ.includes(val)) {
        matched = true;
      }

      if (matched) {
        activeRuleName = rule.name;
        if (rule.action.pinDocId) {
          pinnedDocId = rule.action.pinDocId;
          pinPosition = rule.action.pinPosition || 1;
        }
        if (rule.action.boostCategory) {
          boostCategory = rule.action.boostCategory;
        }
        break;
      }
    }

    // 3. Filter documents based on provided filters
    let eligibleDocs = this.documents.filter((doc) => {
      for (const [key, filterVal] of Object.entries(filters)) {
        if (filterVal === undefined || filterVal === null || filterVal === '' || filterVal === 'all') {
          continue;
        }
        const docVal = doc[key];
        if (docVal === undefined) return false;

        if (key === 'priceMax' && typeof filterVal === 'number') {
          if (typeof doc.price === 'number' && doc.price > filterVal) return false;
          continue;
        }
        if (key === 'priceMin' && typeof filterVal === 'number') {
          if (typeof doc.price === 'number' && doc.price < filterVal) return false;
          continue;
        }
        if (key === 'minRating' && typeof filterVal === 'number') {
          if (typeof doc.rating === 'number' && doc.rating < filterVal) return false;
          continue;
        }
        if (key === 'inStockOnly' && filterVal === true) {
          if (typeof doc.stock === 'number' && doc.stock <= 0) return false;
          continue;
        }

        if (Array.isArray(docVal)) {
          if (!docVal.map(String).includes(String(filterVal))) return false;
        } else if (String(docVal).toLowerCase() !== String(filterVal).toLowerCase()) {
          return false;
        }
      }
      return true;
    });

    // 4. Generate Query Vector Embedding
    const queryVector = options.vectorQuery || generateDenseEmbedding(rawQuery, this.schema.vectorDimension || 64);

    // 5. Precompute BM25 statistics
    const searchableFields = this.schema.relevance.searchableAttributes;
    const docCount = eligibleDocs.length;
    const k1 = 1.2;
    const b = 0.75;

    // Document lengths for normalization
    const docLengths = new Map<string, number>();
    let totalLength = 0;

    for (const doc of eligibleDocs) {
      let len = 0;
      for (const attr of searchableFields) {
        const val = doc[attr.field];
        if (val) {
          const t = Array.isArray(val) ? val.join(' ') : String(val);
          len += tokenize(t).length;
        }
      }
      docLengths.set(doc.id, len);
      totalLength += len;
    }
    const avgDocLength = docCount > 0 ? totalLength / docCount : 1;

    // Compute IDF for expanded tokens
    const idfMap = new Map<string, number>();
    for (const token of expandedTokens) {
      let docFreq = 0;
      for (const doc of eligibleDocs) {
        for (const attr of searchableFields) {
          const val = doc[attr.field];
          if (val) {
            const strVal = Array.isArray(val) ? val.join(' ') : String(val);
            if (strVal.toLowerCase().includes(token)) {
              docFreq++;
              break;
            }
          }
        }
      }
      // Smoothed IDF
      const idf = Math.log(1 + (docCount - docFreq + 0.5) / (docFreq + 0.5));
      idfMap.set(token, Math.max(0.1, idf));
    }

    // 6. Score each document
    let scoredHits: SearchResultHit[] = [];

    for (const doc of eligibleDocs) {
      let bm25Score = 0;
      let exactBonus = 0;
      let typoPenaltyTotal = 0;
      const matchedFieldsList: string[] = [];

      // A. Keyword / BM25 calculation
      if (rawQuery.length > 0) {
        const docLen = docLengths.get(doc.id) || avgDocLength;
        const normFactor = 1 - b + b * (docLen / (avgDocLength || 1));

        for (const attr of searchableFields) {
          const fieldVal = doc[attr.field];
          if (!fieldVal) continue;

          const textString = Array.isArray(fieldVal) ? fieldVal.join(' ') : String(fieldVal);
          const fieldTokens = tokenize(textString);
          const fieldWeight = attr.weight || 1;

          // Check exact substring match bonus
          if (textString.toLowerCase().includes(rawQuery.toLowerCase())) {
            exactBonus += 1.5 * fieldWeight;
            if (!matchedFieldsList.includes(attr.field)) matchedFieldsList.push(attr.field);
          }

          // Check token matches & typos
          for (const qToken of expandedTokens) {
            let termFreq = 0;
            let bestTypoCost = 99;

            for (const fToken of fieldTokens) {
              if (fToken === qToken || fToken.startsWith(qToken)) {
                termFreq += 1;
                bestTypoCost = 0;
              } else if (this.schema.relevance.typoTolerance.enabled && !this.schema.relevance.typoTolerance.disableOnFields.includes(attr.field)) {
                const dist = damerauLevenshtein(qToken, fToken);
                const minForOne = this.schema.relevance.typoTolerance.minWordSizeForOneTypo;
                const minForTwo = this.schema.relevance.typoTolerance.minWordSizeForTwoTypos;

                if (dist === 1 && qToken.length >= minForOne) {
                  termFreq += 0.7; // slight penalty for 1 typo
                  if (dist < bestTypoCost) bestTypoCost = 1;
                } else if (dist === 2 && qToken.length >= minForTwo) {
                  termFreq += 0.45; // penalty for 2 typos
                  if (dist < bestTypoCost) bestTypoCost = 2;
                }
              }
            }

            if (termFreq > 0) {
              if (!matchedFieldsList.includes(attr.field)) {
                matchedFieldsList.push(attr.field);
              }
              const idf = idfMap.get(qToken) || 0.5;
              const tfComponent = (termFreq * (k1 + 1)) / (termFreq + k1 * normFactor);
              bm25Score += idf * tfComponent * fieldWeight;

              if (bestTypoCost > 0 && bestTypoCost < 99) {
                typoPenaltyTotal += bestTypoCost * 0.2;
              }
            }
          }
        }
      } else {
        // Empty query matches all
        bm25Score = 1.0;
      }

      // B. Vector Cosine Similarity
      let vectorScore = 0;
      if (doc._vector && Array.isArray(doc._vector)) {
        vectorScore = cosineSimilarity(queryVector, doc._vector);
      }

      // C. Custom Ranking Boost (business metrics: sales_count, rating, etc.)
      let customBoost = 0;
      for (const rankRule of this.schema.relevance.customRanking || []) {
        const val = doc[rankRule.field];
        if (typeof val === 'number') {
          if (rankRule.field === 'sales_count' || rankRule.field === 'views' || rankRule.field === 'votes') {
            customBoost += Math.log10(val + 1) * 0.05;
          } else if (rankRule.field === 'rating') {
            customBoost += (val / 5.0) * 0.2;
          }
        }
      }

      // Category boost if merchandising rule matched
      if (boostCategory && (doc.category === boostCategory || doc.section === boostCategory)) {
        customBoost += 0.8;
      }

      // D. Combine according to Hybrid Mode
      let combinedScore = 0;
      if (mode === 'keyword_only') {
        combinedScore = bm25Score + exactBonus - typoPenaltyTotal + customBoost;
      } else if (mode === 'vector_only') {
        combinedScore = vectorScore * 10 + customBoost;
      } else {
        // Hybrid Convex combination
        // Normalize bm25 approx to 0-1 range
        const normalizedBM25 = Math.min(1.0, (bm25Score + exactBonus) / 15);
        combinedScore = (1 - alpha) * normalizedBM25 * 10 + alpha * vectorScore * 10 + customBoost;
      }

      // Generate Highlights
      const highlights: Record<string, string> = {};
      for (const attr of searchableFields) {
        const rawVal = doc[attr.field];
        if (rawVal) {
          const original = Array.isArray(rawVal) ? rawVal.join(', ') : String(rawVal);
          highlights[attr.field] = this.highlightText(original, queryTokens);
        }
      }

      const isPinned = pinnedDocId === doc.id;
      if (isPinned) {
        combinedScore += 1000; // Force to top
      }

      // Filter out zero-relevance documents when query was explicitly typed (unless empty query)
      const hasTextMatch = bm25Score > 0 || exactBonus > 0;
      const hasSemanticMatch = vectorScore > 0.45;

      if (rawQuery.length === 0 || hasTextMatch || (mode !== 'keyword_only' && hasSemanticMatch) || isPinned) {
        scoredHits.push({
          id: doc.id,
          document: doc,
          score: Number(combinedScore.toFixed(3)),
          breakdown: {
            bm25Score: Number(bm25Score.toFixed(2)),
            vectorScore: Number(vectorScore.toFixed(4)),
            combinedScore: Number(combinedScore.toFixed(3)),
            customRankBoost: Number(customBoost.toFixed(2)),
            exactMatchBonus: Number(exactBonus.toFixed(2)),
            typoPenalty: Number(typoPenaltyTotal.toFixed(2)),
            matchedFields: matchedFieldsList,
            isPinned,
            pinPosition: isPinned ? pinPosition : undefined,
          },
          highlights,
        });
      }
    }

    // 7. Sort Results
    if (options.sortBy) {
      const sortField = options.sortBy;
      const order = options.sortOrder === 'asc' ? 1 : -1;
      scoredHits.sort((a, b) => {
        if (a.breakdown.isPinned) return -1;
        if (b.breakdown.isPinned) return 1;
        const valA = a.document[sortField];
        const valB = b.document[sortField];
        if (valA < valB) return -1 * order;
        if (valA > valB) return 1 * order;
        return b.score - a.score;
      });
    } else {
      scoredHits.sort((a, b) => {
        if (a.breakdown.isPinned) return -1;
        if (b.breakdown.isPinned) return 1;
        return b.score - a.score;
      });
    }

    // 8. Compute Facet Distributions
    const facets: Record<string, FacetCount[]> = {};
    for (const field of this.schema.fields.filter((f) => f.filterable)) {
      const countMap = new Map<string, number>();
      for (const hit of scoredHits) {
        const val = hit.document[field.name];
        if (Array.isArray(val)) {
          for (const v of val) {
            countMap.set(String(v), (countMap.get(String(v)) || 0) + 1);
          }
        } else if (val !== undefined && val !== null) {
          countMap.set(String(val), (countMap.get(String(val)) || 0) + 1);
        }
      }
      facets[field.name] = Array.from(countMap.entries())
        .map(([value, count]) => ({ value, count }))
        .sort((a, b) => b.count - a.count);
    }

    // 9. Pagination
    const totalHits = scoredHits.length;
    const totalPages = Math.ceil(totalHits / perPage) || 1;
    const startIndex = (page - 1) * perPage;
    const paginatedHits = scoredHits.slice(startIndex, startIndex + perPage);

    const processingTimeMs = Number((performance.now() - startTime).toFixed(1));

    return {
      hits: paginatedHits,
      totalHits,
      page,
      perPage,
      totalPages,
      processingTimeMs: Math.max(0.8, processingTimeMs),
      query: rawQuery,
      appliedFilters: filters,
      facets,
      activeRuleApplied: activeRuleName,
    };
  }

  /**
   * Expand tokens using one-way and two-way synonym dictionary
   */
  private expandSynonyms(tokens: string[]): string[] {
    const result = new Set<string>(tokens);
    const synonyms = this.schema.relevance.synonyms || [];

    for (const token of tokens) {
      for (const syn of synonyms) {
        if (syn.type === 'two-way') {
          if (syn.terms.map((t) => t.toLowerCase()).includes(token.toLowerCase())) {
            syn.terms.forEach((t) => result.add(t.toLowerCase()));
          }
        } else if (syn.type === 'one-way') {
          if (syn.rootTerm && syn.rootTerm.toLowerCase() === token.toLowerCase()) {
            syn.terms.forEach((t) => result.add(t.toLowerCase()));
          }
        }
      }
    }

    return Array.from(result);
  }

  /**
   * Inject highlight HTML tags into text
   */
  private highlightText(text: string, tokens: string[]): string {
    if (!text || tokens.length === 0) return text;
    let safe = text.replace(/</g, '&lt;').replace(/>/g, '&gt;');

    for (const t of tokens) {
      if (t.length < 2) continue;
      const regex = new RegExp(`(${t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
      safe = safe.replace(regex, '<mark class="search-highlight">$1</mark>');
    }

    return safe;
  }
}
