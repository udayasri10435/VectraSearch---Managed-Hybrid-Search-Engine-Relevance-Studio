/**
 * Math and vector utilities for BM25, Levenshtein, and semantic vector embeddings
 */

// Basic semantic vocabulary dictionary for generating coherent vector embeddings
const SEMANTIC_CLUSTERS: Record<string, number[]> = {
  // Electronics & Mobile
  phone: [0.85, 0.45, 0.1, 0.9, 0.12, 0.05, 0.78, 0.6],
  smartphone: [0.88, 0.44, 0.11, 0.92, 0.14, 0.06, 0.8, 0.62],
  mobile: [0.82, 0.4, 0.12, 0.85, 0.15, 0.04, 0.75, 0.58],
  iphone: [0.92, 0.5, 0.15, 0.95, 0.2, 0.08, 0.85, 0.7],
  android: [0.86, 0.46, 0.12, 0.91, 0.16, 0.07, 0.81, 0.63],
  laptop: [0.4, 0.88, 0.6, 0.25, 0.8, 0.1, 0.5, 0.75],
  computer: [0.38, 0.9, 0.65, 0.22, 0.82, 0.12, 0.52, 0.78],
  macbook: [0.42, 0.92, 0.62, 0.28, 0.85, 0.15, 0.55, 0.8],
  audio: [0.1, 0.2, 0.9, 0.15, 0.3, 0.85, 0.4, 0.3],
  headphones: [0.12, 0.22, 0.94, 0.18, 0.32, 0.88, 0.42, 0.32],
  earbuds: [0.14, 0.2, 0.92, 0.2, 0.3, 0.86, 0.4, 0.3],
  camera: [0.3, 0.35, 0.4, 0.45, 0.5, 0.3, 0.9, 0.85],
  lens: [0.28, 0.32, 0.38, 0.42, 0.48, 0.28, 0.92, 0.88],

  // Developer & Docs
  api: [0.05, 0.85, 0.2, 0.1, 0.9, 0.7, 0.1, 0.4],
  sdk: [0.06, 0.88, 0.22, 0.12, 0.92, 0.72, 0.12, 0.42],
  database: [0.1, 0.9, 0.15, 0.08, 0.85, 0.75, 0.05, 0.5],
  vector: [0.2, 0.95, 0.3, 0.15, 0.88, 0.8, 0.1, 0.6],
  search: [0.25, 0.92, 0.28, 0.18, 0.85, 0.78, 0.15, 0.58],
  indexing: [0.22, 0.9, 0.25, 0.16, 0.86, 0.76, 0.12, 0.55],
  query: [0.24, 0.91, 0.26, 0.17, 0.84, 0.77, 0.14, 0.56],
  elasticsearch: [0.28, 0.94, 0.32, 0.2, 0.89, 0.82, 0.16, 0.6],
  bm25: [0.26, 0.93, 0.3, 0.19, 0.87, 0.8, 0.14, 0.59],

  // Media & Movies
  movie: [0.6, 0.1, 0.7, 0.3, 0.2, 0.65, 0.75, 0.4],
  cinema: [0.62, 0.12, 0.72, 0.32, 0.22, 0.68, 0.78, 0.42],
  film: [0.61, 0.11, 0.71, 0.31, 0.21, 0.66, 0.76, 0.41],
  action: [0.75, 0.15, 0.8, 0.4, 0.25, 0.7, 0.85, 0.5],
  drama: [0.55, 0.08, 0.65, 0.28, 0.18, 0.6, 0.7, 0.38],
  scifi: [0.8, 0.7, 0.75, 0.45, 0.6, 0.75, 0.88, 0.7],
  director: [0.5, 0.2, 0.6, 0.25, 0.3, 0.55, 0.7, 0.45],
};

const DEFAULT_DIMENSION = 64;

/**
 * Deterministic string hash
 */
function hashString(str: string): number {
  let hash = 5381;
  for (let i = 0; i < str.length; i++) {
    hash = ((hash << 5) + hash) + str.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash);
}

/**
 * Generate a dense unit-normalized embedding vector for any text
 */
export function generateDenseEmbedding(text: string, dimension: number = DEFAULT_DIMENSION): number[] {
  if (!text || text.trim() === '') {
    const empty = new Array(dimension).fill(0);
    empty[0] = 1;
    return empty;
  }

  const tokens = text.toLowerCase()
    .replace(/[^\w\s]/g, ' ')
    .split(/\s+/)
    .filter(Boolean);

  const vec = new Array(dimension).fill(0);

  for (let i = 0; i < tokens.length; i++) {
    const token = tokens[i];
    const weight = 1.0 / Math.sqrt(i + 1); // slight positional decay

    // Check if we have semantic cluster seed
    if (SEMANTIC_CLUSTERS[token]) {
      const cluster = SEMANTIC_CLUSTERS[token];
      for (let d = 0; d < dimension; d++) {
        const seedVal = cluster[d % cluster.length];
        vec[d] += seedVal * 2.0 * weight;
      }
    }

    // Blend character n-grams and token hash to project into hyperspace
    const tHash = hashString(token);
    for (let d = 0; d < dimension; d++) {
      const freq = Math.sin((tHash * (d + 1) * 0.37)) * Math.cos(d * 0.19);
      vec[d] += freq * weight;
    }
  }

  // Normalize vector to unit length (L2 norm = 1.0)
  let norm = 0;
  for (let d = 0; d < dimension; d++) {
    norm += vec[d] * vec[d];
  }
  norm = Math.sqrt(norm);

  if (norm > 0) {
    for (let d = 0; d < dimension; d++) {
      vec[d] = Number((vec[d] / norm).toFixed(5));
    }
  } else {
    vec[0] = 1.0;
  }

  return vec;
}

/**
 * Cosine similarity between two vectors
 */
export function cosineSimilarity(a: number[], b: number[]): number {
  if (!a || !b || a.length === 0 || b.length === 0) return 0;
  const len = Math.min(a.length, b.length);
  let dotProduct = 0;
  let normA = 0;
  let normB = 0;

  for (let i = 0; i < len; i++) {
    dotProduct += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }

  const denominator = Math.sqrt(normA) * Math.sqrt(normB);
  if (denominator === 0) return 0;
  const score = dotProduct / denominator;
  // clamp between 0 and 1
  return Math.max(0, Math.min(1, (score + 1) / 2));
}

/**
 * Damerau-Levenshtein distance (typo calculation)
 */
export function damerauLevenshtein(a: string, b: string): number {
  const al = a.length;
  const bl = b.length;
  if (al === 0) return bl;
  if (bl === 0) return al;

  const matrix: number[][] = [];
  for (let i = 0; i <= al; i++) {
    matrix[i] = [i];
  }
  for (let j = 0; j <= bl; j++) {
    matrix[0][j] = j;
  }

  for (let i = 1; i <= al; i++) {
    for (let j = 1; j <= bl; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      let min = Math.min(
        matrix[i - 1][j] + 1,       // deletion
        matrix[i][j - 1] + 1,       // insertion
        matrix[i - 1][j - 1] + cost // substitution
      );

      // transposition
      if (i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) {
        min = Math.min(min, matrix[i - 2][j - 2] + cost);
      }

      matrix[i][j] = min;
    }
  }

  return matrix[al][bl];
}

/**
 * Tokenize string for BM25
 */
export function tokenize(str: string): string[] {
  if (!str) return [];
  return str
    .toLowerCase()
    .replace(/[^\w\s-]/g, ' ')
    .split(/[\s-]+/)
    .filter((t) => t.length > 0);
}
