export type FieldType = 'string' | 'number' | 'boolean' | 'array' | 'vector';

export interface FieldDefinition {
  name: string;
  type: FieldType;
  searchable: boolean;
  filterable: boolean;
  sortable: boolean;
  boost: number;
}

export interface SearchableAttributeWeight {
  field: string;
  weight: number;
}

export interface CustomRankingRule {
  field: string;
  order: 'asc' | 'desc';
}

export interface TypoToleranceConfig {
  enabled: boolean;
  minWordSizeForOneTypo: number;
  minWordSizeForTwoTypos: number;
  disableOnFields: string[];
}

export interface SynonymRule {
  id: string;
  type: 'two-way' | 'one-way';
  terms: string[];
  rootTerm?: string; // used for one-way (e.g. root: "phone" => ["cellular", "mobile", "handset"])
}

export interface MerchandisingRule {
  id: string;
  name: string;
  enabled: boolean;
  condition: {
    type: 'query_exact' | 'query_contains' | 'category_match';
    value: string;
  };
  action: {
    pinDocId?: string;
    pinPosition?: number;
    boostCategory?: string;
    hideDocId?: string;
    applyFilter?: string;
  };
}

export interface HybridConfig {
  mode: 'hybrid' | 'keyword_only' | 'vector_only';
  alpha: number; // 0.0 = pure BM25 keyword, 1.0 = pure vector cosine, 0.5 = balanced
  rrfK: number;  // Reciprocal Rank Fusion constant, default 60
}

export interface RelevanceSettings {
  searchableAttributes: SearchableAttributeWeight[];
  customRanking: CustomRankingRule[];
  typoTolerance: TypoToleranceConfig;
  synonyms: SynonymRule[];
  rules: MerchandisingRule[];
  hybridConfig: HybridConfig;
  prefixSearch: 'last_word' | 'all' | 'disabled';
}

export interface IndexSchema {
  id: string;
  name: string;
  description: string;
  primaryKey: string;
  fields: FieldDefinition[];
  vectorDimension: number;
  distanceMetric: 'cosine' | 'dot_product' | 'euclidean';
  createdAt: string;
  relevance: RelevanceSettings;
}

export interface DocumentRecord {
  id: string;
  [key: string]: any;
}

export interface ScoreBreakdown {
  bm25Score: number;
  vectorScore: number;
  combinedScore: number;
  customRankBoost: number;
  exactMatchBonus: number;
  typoPenalty: number;
  matchedFields: string[];
  isPinned?: boolean;
  pinPosition?: number;
}

export interface SearchResultHit {
  id: string;
  document: DocumentRecord;
  score: number;
  breakdown: ScoreBreakdown;
  highlights: Record<string, string>;
}

export interface FacetCount {
  value: string;
  count: number;
}

export interface SearchResponse {
  hits: SearchResultHit[];
  totalHits: number;
  page: number;
  perPage: number;
  totalPages: number;
  processingTimeMs: number;
  query: string;
  appliedFilters: Record<string, any>;
  facets: Record<string, FacetCount[]>;
  activeRuleApplied?: string;
}

export interface SearchQueryOptions {
  query: string;
  mode?: 'hybrid' | 'keyword_only' | 'vector_only';
  alpha?: number;
  filters?: Record<string, any>;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
  page?: number;
  perPage?: number;
  vectorQuery?: number[];
}

export interface QueryLog {
  id: string;
  query: string;
  timestamp: number;
  latencyMs: number;
  hitsCount: number;
  clickedDocId?: string;
  filtersUsed: string[];
  mode: string;
}

export interface ApiKeyItem {
  id: string;
  name: string;
  key: string;
  role: 'admin' | 'search_only' | 'scoped';
  indexScope?: string;
  rateLimit: number; // requests/sec
  createdAt: string;
  lastUsedAt?: string;
}
