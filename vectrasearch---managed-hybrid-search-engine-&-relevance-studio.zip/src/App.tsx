/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useCallback } from 'react';
import {
  INITIAL_INDEXES,
  buildInitialDocuments,
  INITIAL_API_KEYS,
} from './data/sampleDatasets';
import { IndexSchema, DocumentRecord, ApiKeyItem } from './engine/types';
import { SearchEngine } from './engine/searchEngine';
import { AnalyticsTracker } from './engine/analyticsStore';
import { Navbar } from './components/Navbar';
import { SearchStudio } from './components/SearchStudio';
import { RelevanceTuning } from './components/RelevanceTuning';
import { IndexInspector } from './components/IndexInspector';
import { AnalyticsView } from './components/AnalyticsView';
import { ApiKeysView } from './components/ApiKeysView';
import { NewIndexModal } from './components/NewIndexModal';

export default function App() {
  // Navigation & Active Index State
  const [activeTab, setActiveTab] = useState<'studio' | 'relevance' | 'inspector' | 'analytics' | 'api'>('studio');
  const [indexes, setIndexes] = useState<IndexSchema[]>(INITIAL_INDEXES);
  const [currentIndexId, setCurrentIndexId] = useState<string>('ecommerce_catalog');
  const [isNewIndexModalOpen, setIsNewIndexModalOpen] = useState(false);

  // Document Stores per Index
  const [documentsMap, setDocumentsMap] = useState<Record<string, DocumentRecord[]>>(() => {
    const map: Record<string, DocumentRecord[]> = {};
    for (const idx of INITIAL_INDEXES) {
      map[idx.id] = buildInitialDocuments(idx.id);
    }
    return map;
  });

  // API Keys state
  const [apiKeys, setApiKeys] = useState<ApiKeyItem[]>(INITIAL_API_KEYS);

  // Shared Analytics Tracker
  const analyticsTracker = useMemo(() => new AnalyticsTracker(), []);

  // Current active schema
  const currentSchema = useMemo(() => {
    return indexes.find((idx) => idx.id === currentIndexId) || indexes[0];
  }, [indexes, currentIndexId]);

  // Current active documents
  const currentDocuments = useMemo(() => {
    return documentsMap[currentIndexId] || [];
  }, [documentsMap, currentIndexId]);

  // Active SearchEngine instance
  const searchEngine = useMemo(() => {
    return new SearchEngine(currentSchema, currentDocuments);
  }, [currentSchema, currentDocuments]);

  // Schema update handler
  const handleUpdateSchema = useCallback((updatedSchema: IndexSchema) => {
    setIndexes((prev) => prev.map((idx) => (idx.id === updatedSchema.id ? updatedSchema : idx)));
  }, []);

  // Document mutation handlers
  const handleAddDocument = useCallback((doc: DocumentRecord) => {
    setDocumentsMap((prev) => {
      const currentList = prev[currentIndexId] || [];
      return {
        ...prev,
        [currentIndexId]: [doc, ...currentList],
      };
    });
  }, [currentIndexId]);

  const handleUpdateDocument = useCallback((id: string, updated: Partial<DocumentRecord>) => {
    setDocumentsMap((prev) => {
      const currentList = prev[currentIndexId] || [];
      return {
        ...prev,
        [currentIndexId]: currentList.map((d) => (d.id === id ? { ...d, ...updated } : d)),
      };
    });
  }, [currentIndexId]);

  const handleDeleteDocument = useCallback((id: string) => {
    setDocumentsMap((prev) => {
      const currentList = prev[currentIndexId] || [];
      return {
        ...prev,
        [currentIndexId]: currentList.filter((d) => d.id !== id),
      };
    });
  }, [currentIndexId]);

  const handleBatchImport = useCallback((docs: DocumentRecord[]) => {
    setDocumentsMap((prev) => {
      const currentList = prev[currentIndexId] || [];
      return {
        ...prev,
        [currentIndexId]: [...docs, ...currentList],
      };
    });
  }, [currentIndexId]);

  // Reset to Demo Data
  const handleResetData = useCallback(() => {
    setIndexes(INITIAL_INDEXES);
    const resetMap: Record<string, DocumentRecord[]> = {};
    for (const idx of INITIAL_INDEXES) {
      resetMap[idx.id] = buildInitialDocuments(idx.id);
    }
    setDocumentsMap(resetMap);
  }, []);

  // Provision new index
  const handleCreateNewIndex = useCallback((newSchema: IndexSchema) => {
    setIndexes((prev) => [...prev, newSchema]);
    setDocumentsMap((prev) => ({
      ...prev,
      [newSchema.id]: [],
    }));
    setCurrentIndexId(newSchema.id);
    setActiveTab('inspector');
  }, []);

  // Quick Action from Analytics: Add Synonym
  const handleQuickAddSynonym = useCallback((failedQuery: string) => {
    const newSynonym = {
      id: 'syn_' + Math.random().toString(36).substring(2, 7),
      type: 'two-way' as const,
      terms: [failedQuery.toLowerCase().trim()],
    };
    const updatedSchema: IndexSchema = {
      ...currentSchema,
      relevance: {
        ...currentSchema.relevance,
        synonyms: [...currentSchema.relevance.synonyms, newSynonym],
      },
    };
    handleUpdateSchema(updatedSchema);
    setActiveTab('relevance');
  }, [currentSchema, handleUpdateSchema]);

  // Quick Action from Analytics: Add Rule
  const handleQuickAddRule = useCallback((failedQuery: string) => {
    const candidateDoc = currentDocuments[0];
    if (!candidateDoc) return;

    const newRule = {
      id: 'rule_' + Math.random().toString(36).substring(2, 7),
      name: `Resolve zero-hit: ${failedQuery}`,
      enabled: true,
      condition: {
        type: 'query_exact' as const,
        value: failedQuery.toLowerCase().trim(),
      },
      action: {
        pinDocId: candidateDoc.id,
        pinPosition: 1,
      },
    };

    const updatedSchema: IndexSchema = {
      ...currentSchema,
      relevance: {
        ...currentSchema.relevance,
        rules: [...currentSchema.relevance.rules, newRule],
      },
    };
    handleUpdateSchema(updatedSchema);
    setActiveTab('relevance');
  }, [currentSchema, currentDocuments, handleUpdateSchema]);

  // API Key handlers
  const handleCreateKey = useCallback((newKey: ApiKeyItem) => {
    setApiKeys((prev) => [newKey, ...prev]);
  }, []);

  const handleRevokeKey = useCallback((id: string) => {
    setApiKeys((prev) => prev.filter((k) => k.id !== id));
  }, []);

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans">
      {/* Top 3-Zone Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        indexes={indexes}
        currentIndexId={currentIndexId}
        onSelectIndex={(id) => setCurrentIndexId(id)}
        onResetData={handleResetData}
        onNewIndexModal={() => setIsNewIndexModalOpen(true)}
      />

      {/* Main Workspace Body */}
      <main className="flex-1 pb-16">
        {activeTab === 'studio' && (
          <SearchStudio
            engine={searchEngine}
            schema={currentSchema}
            analytics={analyticsTracker}
            onNavigateToRelevance={() => setActiveTab('relevance')}
          />
        )}

        {activeTab === 'relevance' && (
          <RelevanceTuning
            schema={currentSchema}
            onUpdateSchema={handleUpdateSchema}
            documentList={currentDocuments.map((d) => ({
              id: d.id,
              title: d.title || d.name,
            }))}
          />
        )}

        {activeTab === 'inspector' && (
          <IndexInspector
            schema={currentSchema}
            documents={currentDocuments}
            onAddDocument={handleAddDocument}
            onUpdateDocument={handleUpdateDocument}
            onDeleteDocument={handleDeleteDocument}
            onBatchImport={handleBatchImport}
          />
        )}

        {activeTab === 'analytics' && (
          <AnalyticsView
            analytics={analyticsTracker}
            schema={currentSchema}
            onQuickAddSynonym={handleQuickAddSynonym}
            onQuickAddRule={handleQuickAddRule}
          />
        )}

        {activeTab === 'api' && (
          <ApiKeysView
            apiKeys={apiKeys}
            onCreateKey={handleCreateKey}
            onRevokeKey={handleRevokeKey}
            schema={currentSchema}
            engine={searchEngine}
          />
        )}
      </main>

      {/* New Index Modal */}
      <NewIndexModal
        isOpen={isNewIndexModalOpen}
        onClose={() => setIsNewIndexModalOpen(false)}
        onCreate={handleCreateNewIndex}
      />
    </div>
  );
}
